jQuery(document).ready(function ($) {
  const templateHtml = $('#product-template').html();

  const addProduct = () => {
    const $template = $(templateHtml);
    const index = $('.product-block').length;

    $template.find('[name]').each(function () {
      const original = $(this).attr('name');
      const updated = original.replace(/\[0\]/g, `[${index}]`);
      $(this).attr('name', updated);
    });

    $template.find('.sale-fields').hide();
    $template.find('.download-fields').hide();
    $template.find('.external-url-wrapper').hide();

    $('#product-container').append($template);
  };

  $('#add-product').on('click', function (e) {
    e.preventDefault();
    productCount = $('#product-container .product-block').length;

    if (productCount >= 2) {
      alert('You can only add up to 2 products at a time.');
      return false;
    }
    addProduct();
  });

  $(document).on('click', '.upload_image_button', function (e) {
    e.preventDefault();
    const button = $(this);
  
    const uploader = wp.media({
      title: 'Select Product Image',
      button: { text: 'Use this image' },
      multiple: false
    });
  
    uploader.on('select', function () {
      const attachment = uploader.state().get('selection').first().toJSON();
      // Remove any previous previews
      button.siblings('img').remove();
      button.after(`
        <input type="hidden" name="product_image[]" value="${attachment.url}">
        <img src="${attachment.url}" style="max-width:100px; display:block; margin-top:5px;">
      `);
    });
  
    uploader.open();
  });
  

  $(document).on('change', '.schedule-sale-checkbox', function () {
    const container = $(this).closest('.product-block');
    const saleFields = container.find('.sale-fields');
    if ($(this).is(':checked')) {
      saleFields.slideDown();
    } else {
      saleFields.slideUp();
    }
  });

  $(document).on('change', '.downloadable-toggle', function () {
    const container = $(this).closest('.product-block');
    const downloadFields = container.find('.download-fields');
    if ($(this).is(':checked')) {
      downloadFields.slideDown();
    } else {
      downloadFields.slideUp();
    }
  });

  $(document).on('change', 'input[name="virtual[]"]', function () {
    const container = $(this).closest('.product-block');
    container.find('.shipping-fields').toggle(!this.checked);
  });

  $(document).on('click', '.add-download-file', function (e) {
    e.preventDefault();
    const $btn = $(this);
    if ($btn.data('clicked')) return;
    $btn.data('clicked', true);

    const container = $btn.closest('.download-fields');
    const block = container.find('.download-file-block:last');
    const clone = block.clone();
    clone.find('input').val('');

    const limitInput = `<label>Download Limit: <input type="number" name="download_limit[]" min="0"></label>`;
    const expiryInput = `<label>Download Expiry (days): <input type="number" name="download_expiry[]" min="0"></label>`;

    container.append(clone).append(limitInput).append(expiryInput);
  });

  $(document).on('change', 'select[name="product_type[]"]', function () {
    const container = $(this).closest('.product-block');
    container.find('.external-url-wrapper').toggle($(this).val() === 'external');
  });

  $('#product-form').on('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    formData.append('action', 'qadd_save_product');
    formData.append('nonce', qadd_ajax.nonce);

    $.ajax({
      url: qadd_ajax.ajax_url,
      method: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      dataType: 'json',
      success: function (res) {
        if (res.success) {
          alert('Products submitted successfully.');
          window.location.href = '/wp-admin/edit.php?post_type=product';
        } else {
          alert('Error submitting products.');
        }
      },
      error: function () {
        alert('Server error submitting products.');
      }
    });
  });

$(document).on('click', '.upload_gallery_images_button', function (e) {
  e.preventDefault();

  const $button = $(this);
  const $wrapper = $button.closest('.product-gallery-wrapper');
  const $preview = $wrapper.find('.gallery-preview');
  const $input = $wrapper.find('.gallery-input');

  const galleryUploader = wp.media({
    title: 'Select Gallery Images',
    button: { text: 'Use these images' },
    multiple: true
  });

  galleryUploader.on('select', function () {
    const selection = galleryUploader.state().get('selection');
    let urls = [];

    $preview.empty();
    selection.each(function (attachment) {
      const url = attachment.toJSON().url;
      urls.push(url);
      $preview.append(`<img src="${url}" class="gallery-thumb">`);
    });

    $input.val(JSON.stringify(urls));
  });

  galleryUploader.open();
});
// === Add Attribute Field ===
$(document).on('click', '.add-attribute-button', function (e) {
  e.preventDefault();

  const $productBlock = $(this).closest('.product-block');
  const $container = $productBlock.find('.attributes-container');
  const $templateHtml = $('.attribute-row-template').html();
  const index = $('.product-block').index($productBlock);

  const $row = $($templateHtml);

  // Update input names with correct index
  $row.find('[name]').each(function () {
    const name = $(this).attr('name');
    const updated = name.replace(/\[0\]/, `[${index}]`);
    $(this).attr('name', updated);
  });

  $container.append($row);
});

// === Toggle attribute variation checkbox visibility ===
$(document).on('change', 'select[name="product_type[]"]', function () {
  const $block = $(this).closest('.product-block');
  const isVariable = $(this).val() === 'variable';
  $block.find('.variation-toggle').toggle(isVariable);
});


  
  
});

$(document).on('click', '.upload_variation_image_button', function (e) {
  e.preventDefault();

  const button = $(this);
  const wrapper = button.closest('.variation-builder');
  const preview = wrapper.find('.variation-image-preview');
  const input = wrapper.find('.variation-image-input');

  const mediaUploader = wp.media({
    title: 'Select Variation Image',
    button: { text: 'Use this image' },
    multiple: false
  });

  mediaUploader.on('select', function () {
    const attachment = mediaUploader.state().get('selection').first().toJSON();
    input.val(attachment.url);
    preview.html(`<img src="${attachment.url}" style="max-width:80px;">`);
  });

  mediaUploader.open();
});



