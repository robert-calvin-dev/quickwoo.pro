<?php
/**
 * Template: Quick Add Product Form
 */
?>
<style>
  .product-block {
    display: inline-block;
    vertical-align: top;
    width: 30%;
    margin: 1%;
    padding: 20px;
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 6px;
    box-sizing: border-box;
  }
  .product-block label {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    gap: 10px;
  }
  .product-block label select,
  .product-block label textarea {
    flex: 1 1 auto;
    max-width: 60%;
  }
  .product-block input[type="checkbox"] {
    margin-left: auto;
  }
  .product-block .download-file-block label,
  .product-block .sale-fields label,
  .product-block .external-url-wrapper label {
    flex-direction: column;
    align-items: flex-start;
  }
  .download-file-block,
  .sale-fields,
  .external-url-wrapper,
  .download-fields,
  .shipping-fields {
    margin-left: 10px;
  }
  .gallery-preview {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  margin-top: 10px;
}

.gallery-preview img.gallery-thumb {
  width: 80px;
  height: auto;
  object-fit: cover;
  border: 1px solid #ccc;
}

  @media screen and (max-width: 768px) {
    .product-block {
      width: 100%;
      margin-bottom: 20px;
    }
  }
</style>
<div class="product-block">
    <h2>New Product</h2>
    <label>Product Name <input type="text" name="product_name[0]"></label>
    <label>Product Type <select name="product_type[0]">
        <option value="simple">Simple</option>
        <option value="variable">Variable</option>
        <option value="grouped">Grouped</option>
        <option value="external">External/Affiliate</option>
      </select></label>
    <label>SKU <input type="text" name="sku[0]"></label>
    <label>GTIN/UPC/EAN/ISBN <input type="text" name="gtin[0]"></label>
<!-- Product Image -->
<div class="form-field product-image-wrapper">

  <button class="upload_image_button button">Upload Product Image</button>
  <!-- Hidden input added dynamically via JS -->
</div>

<!-- Product Gallery Images -->
<div class="form-field product-gallery-wrapper">

  <button class="upload_gallery_images_button button">Add Gallery Images</button>

  <div class="gallery-preview"></div>

  <input type="hidden" name="product_gallery[0]" class="gallery-input">
</div>
    <label>Regular Price <input type="number" name="regular_price[0]" min="0" step="0.01"></label>
    <label>Sale Price <input type="number" name="sale_price[0]" min="0" step="0.01"></label>
    <label><input type="checkbox" class="schedule-sale-checkbox" name="schedule_sale[0]"> Schedule Sale</label>
    <div class="sale-fields">
      <label>Sale Start Date <input type="date" name="sale_start[0]" class="wc_input_datetime"></label>
      <label>Sale End Date <input type="date" name="sale_end[0]" class="wc_input_datetime"></label>
    </div>
    <label>Product Description <textarea name="product_description[0]"></textarea></label>
    <label>Short Description <textarea name="short_description[0]"></textarea></label>
    <label>Categories <input type="text" name="categories[0]" placeholder="Comma-separated"></label>
    <label>Tags <input type="text" name="tags[0]" placeholder="Comma-separated"></label>
    <label>Tax Status <select name="tax_status[0]">
        <option value="taxable">Taxable</option>
        <option value="shipping">Shipping only</option>
        <option value="none">None</option>
      </select></label>
    <label>Tax Class <input type="text" name="tax_class[0]"></label>
    <label>Weight <input type="number" name="weight[0]" step="0.01"></label>
    <label>Length <input type="number" name="length[0]" step="0.01"></label>
    <label>Width <input type="number" name="width[0]" step="0.01"></label>
    <label>Height <input type="number" name="height[0]" step="0.01"></label>
    <label>Shipping Class <input type="text" name="shipping_class[0]"></label>
    <label><input type="checkbox" name="manage_stock[0]"> Manage Stock</label>
    <label>Stock Quantity <input type="number" name="stock_quantity[0]"></label>
    <label>Allow Backorders <select name="backorders[0]">
        <option value="no">Do not allow</option>
        <option value="notify">Allow, but notify</option>
        <option value="yes">Allow</option>
      </select></label>
    <label>Stock Status <select name="stock_status[0]">
        <option value="instock">In stock</option>
        <option value="outofstock">Out of stock</option>
        <option value="onbackorder">On backorder</option>
      </select></label>
    <label><input type="checkbox" name="sold_individually[0]"> Sold Individually</label>
    <div class="external-url-wrapper">
      <label>External URL <input type="url" name="external_url[0]"></label>
      <label>Button Text <input type="text" name="button_text[0]"></label>
    </div>
    <label><input type="checkbox" name="virtual[0]"> Virtual</label>
    <label><input type="checkbox" class="downloadable-toggle" name="downloadable[0]"> Downloadable</label>
    <div class="download-fields" style="display:none">
      <div class="download-file-block">
        <label>Download URL <input type="url" name="download_url[0][]"></label>
        <label>Download Name <input type="text" name="download_name[0][]"></label>
      </div>
      <label>Download Limit <input type="number" name="download_limit[0]" min="0"></label>
      <label>Download Expiry (days) <input type="number" name="download_expiry[0]" min="0"></label>

    </div>
    <label>Purchase Note <textarea name="purchase_note[0]"></textarea></label>
    <label><input type="checkbox" name="reviews_allowed[0]" checked> Enable Reviews</label>
    <label>Slug <input type="text" name="slug[0]"></label>
    <label>Menu Order <input type="number" name="menu_order[0]" value="0"></label>
    <label>Catalog Visibility <select name="catalog_visibility[0]">
        <option value="visible">Shop and search</option>
        <option value="catalog">Shop only</option>
        <option value="search">Search only</option>
        <option value="hidden">Hidden</option>
      </select></label>
    <label>Status <select name="status[0]">
        <option value="publish">Publish</option>
        <option value="draft">Draft</option>
        <option value="pending">Pending</option>
      </select></label>
      <!-- Attributes Section -->
<div class="attributes-wrapper">
  <label><strong>Attributes</strong></label>
  <div class="attributes-container"></div>
  <button class="add-attribute-button button">Add Attribute</button>
</div>
<!-- Attribute Row Template -->
<div class="attribute-row-template" style="display:none;">
  <div class="attribute-row" style="margin-bottom:10px; border:1px solid #ccc; padding:10px;">
    <input type="text" name="attribute_name[0][]" placeholder="Attribute Name" style="margin-right:10px;">
    <br>
    <input type="text" name="attribute_values[0][]" placeholder="Comma-separated values" style="margin-right:10px;">
    <label class="variation-toggle" style="display:none;">
      <input type="checkbox" name="attribute_variation[0][]"> Used for variations?
    </label>
  </div>
</div>

  </div>
