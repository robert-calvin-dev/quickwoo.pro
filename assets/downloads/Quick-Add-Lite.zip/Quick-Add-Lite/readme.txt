=== Quick Add Lite ===
Contributors: robertcalvin  
Tags: woocommerce, products, bulk add, admin tools, inventory  
Requires at least: 5.8  
Tested up to: 6.8  
Requires PHP: 7.4  
Stable tag: 1.0  
License: GPLv2 or later  
License URI: https://www.gnu.org/licenses/gpl-2.0.html  

Create up to **two** WooCommerce products at a time from a streamlined admin form.

== Description ==

**Quick Add Lite** is a simplified version of the full **Quick Add** plugin for WooCommerce.

This free version supports:

- Product name, description, and short description  
- SKU, pricing, inventory, and stock status  
- Product image support  
- Category and tag assignment  

Want more power?

💡 **Upgrade to the full version** to unlock:
- Unlimited product creation  
- Downloadable files per product  
- Variable, grouped, and external product types  
- Product attributes and variation builder  
- Custom meta fields (GTIN, shipping class, etc.)  
- Product galleries and more  

Learn more or purchase at: [quickwoo.com/quick-add](https://quickwoo.com/quick-add)

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/quick-add-lite/`  
2. Activate the plugin from the WordPress **Plugins** screen  
3. Go to **Quick Add** in your admin menu to start adding products  

== Screenshots ==

1. Add up to two WooCommerce products via a compact form  
2. Input fields for product basics like price, SKU, and categories  

== Changelog ==

= 1.0 =  
* Initial release of Quick Add Lite  
* Supports two products at once  

== Frequently Asked Questions ==

= Why only two products? =  
This is a free lite version. The full version removes that limit and unlocks advanced features.

= How do I upgrade? =  
Visit [quickwoo.com/quick-add](https://quickwoo.com/quick-add) to get the full version.

= Does this support variations or downloadable products? =  
Not in the lite version. You’ll need the full plugin for those features.

== Upgrade Notice ==

= 1.0 =  
Quick Add Lite released. Limited to 2 products. Upgrade for more.

== License ==

This plugin is licensed under the [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html).
