<?php
/**
 * Plugin Name: Quick Edit Lite
 * Plugin URI: https://quickwoo.com/quick-edit-lite
 * Description: Quickly edit WooCommerce products in a spreadsheet-style interface. Limit 5 editable products in Lite.
 * Version: 1.0
 * Author: Robert Calvin
 * Author URI: https://quickwoo.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: quick-edit-lite
 */

defined('ABSPATH') || exit;

add_action('admin_menu', 'qedit_register_menu');
function qedit_register_menu() {
    add_menu_page(
        esc_html__('Quick Edit Lite', 'quick-edit-lite'),
        esc_html__('Quick Edit Lite', 'quick-edit-lite'),
        'manage_woocommerce',
        'quick-edit-lite',
        'qedit_render_page',
        'dashicons-edit',
        59
    );
}

add_action('admin_enqueue_scripts', 'qedit_enqueue_assets');
function qedit_enqueue_assets($hook) {
    if ($hook !== 'toplevel_page_quick-edit-lite') return;

    wp_enqueue_style('qedit-lite-style', plugin_dir_url(__FILE__) . 'qedit-style.css');
    wp_enqueue_script('qedit-lite-script', plugin_dir_url(__FILE__) . 'qedit-script.js', ['jquery'], null, true);

    wp_localize_script('qedit-lite-script', 'qedit_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('qedit_nonce')
    ]);
}

function qedit_render_page() {
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Quick Edit Lite', 'quick-edit-lite'); ?></h1>
        <div class="notice notice-info">
            <?php esc_html_e('This is the Lite version. You can edit up to 5 products.', 'quick-edit-lite'); ?>
            <a href="https://quickwoo.com/product/quick-edit-pro" target="_blank" class="button-primary" style="margin-left: 10px;">
                <?php esc_html_e('Upgrade to Pro', 'quick-edit-lite'); ?>
            </a>
        </div>
        <form id="qedit-form">
            <?php include plugin_dir_path(__FILE__) . 'qedit-template.php'; ?>
            <p>
                <button type="submit" class="button button-primary"><?php esc_html_e('Save Changes', 'quick-edit-lite'); ?></button>
            </p>
        </form>
    </div>
    <?php
}

add_action('wp_ajax_qedit_save_edits', 'qedit_save_edits');
function qedit_save_edits() {
    check_ajax_referer('qedit_nonce', 'nonce');

    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error(esc_html__('Unauthorized access.', 'quick-edit-lite'));
    }

    if (empty($_POST['products']) || !is_array($_POST['products'])) {
        wp_send_json_error(esc_html__('No product data received.', 'quick-edit-lite'));
    }

    $updates = [];
    foreach ($_POST['products'] as $id => $fields) {
        $product_id = absint($id);
        $product = wc_get_product($product_id);

        if (!$product) continue;

        if (isset($fields['title'])) {
            wp_update_post([
                'ID' => $product_id,
                'post_title' => sanitize_text_field($fields['title'])
            ]);
        }

        if (isset($fields['sku'])) {
            $product->set_sku(sanitize_text_field($fields['sku']));
        }

        if (isset($fields['price'])) {
            $product->set_regular_price(sanitize_text_field($fields['price']));
        }

        if (isset($fields['stock'])) {
            $product->set_stock_quantity(intval($fields['stock']));
        }

        if (isset($fields['status'])) {
            $product->set_status(sanitize_key($fields['status']));
        }

        if (isset($fields['categories'])) {
            wp_set_post_terms($product_id, array_map('sanitize_text_field', explode(',', $fields['categories'])), 'product_cat');
        }

        if (isset($fields['tags'])) {
            wp_set_post_terms($product_id, array_map('sanitize_text_field', explode(',', $fields['tags'])), 'product_tag');
        }

        $product->save();
        $updates[] = $product_id;
    }

    wp_send_json_success(esc_html__('Products updated: ', 'quick-edit-lite') . implode(', ', $updates));
}
