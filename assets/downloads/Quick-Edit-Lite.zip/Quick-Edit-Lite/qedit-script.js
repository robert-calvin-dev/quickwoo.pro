jQuery(document).ready(function ($) {
 $('#qedit-form').on('submit', function (e) {
   e.preventDefault();

   const products = {};

   $('tr[data-product-id]').each(function () {
     const row = $(this);
     const id = row.data('product-id');

     products[id] = {
       title: row.find('input[name="title"]').val(),
       sku: row.find('input[name="sku"]').val(),
       price: row.find('input[name="price"]').val(),
       stock: row.find('input[name="stock"]').val(),
       status: row.find('select[name="status"]').val(),
       categories: row.find('input[name="categories"]').val(),
       tags: row.find('input[name="tags"]').val()
     };
   });

   $.ajax({
     url: qedit_ajax.ajax_url,
     method: 'POST',
     data: {
       action: 'qedit_save_edits',
       nonce: qedit_ajax.nonce,
       products: products
     },
     success: function (res) {
       if (res.success) {
         alert('✔ ' + res.data);
         location.reload(); // Optional: reload to fetch updated values
       } else {
         alert('✖ ' + res.data);
       }
     },
     error: function () {
       alert('Server error occurred while saving products.');
     }
   });
 });
});
