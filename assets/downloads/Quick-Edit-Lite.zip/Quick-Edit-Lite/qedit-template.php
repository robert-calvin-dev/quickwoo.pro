<?php
if (!defined('ABSPATH')) exit;

$args = [
    'limit' => 5,
    'orderby' => 'ID',
    'order' => 'DESC',
    'return' => 'objects',
    'status' => ['publish', 'draft', 'pending', 'private']
];
$products = wc_get_products($args);
?>

<table class="wp-list-table widefat fixed striped">
    <thead>
        <tr>
            <th><?php esc_html_e('ID', 'quick-edit-lite'); ?></th>
            <th><?php esc_html_e('Title', 'quick-edit-lite'); ?></th>
            <th><?php esc_html_e('SKU', 'quick-edit-lite'); ?></th>
            <th><?php esc_html_e('Price', 'quick-edit-lite'); ?></th>
            <th><?php esc_html_e('Stock', 'quick-edit-lite'); ?></th>
            <th><?php esc_html_e('Status', 'quick-edit-lite'); ?></th>
            <th><?php esc_html_e('Categories', 'quick-edit-lite'); ?></th>
            <th><?php esc_html_e('Tags', 'quick-edit-lite'); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($products as $product): ?>
            <tr data-product-id="<?php echo esc_attr($product->get_id()); ?>">
                <td><?php echo esc_html($product->get_id()); ?></td>
                <td><input type="text" name="title" value="<?php echo esc_attr($product->get_title()); ?>"></td>
                <td><input type="text" name="sku" value="<?php echo esc_attr($product->get_sku()); ?>"></td>
                <td><input type="number" step="0.01" name="price" value="<?php echo esc_attr($product->get_regular_price()); ?>"></td>
                <td><input type="number" name="stock" value="<?php echo esc_attr($product->get_stock_quantity()); ?>"></td>
                <td>
                    <select name="status">
                        <?php
                        $statuses = ['publish', 'draft', 'pending', 'private'];
                        foreach ($statuses as $status):
                            $selected = $product->get_status() === $status ? 'selected' : '';
                        ?>
                            <option value="<?php echo esc_attr($status); ?>" <?php echo esc_attr($selected); ?>>
                                <?php echo esc_html(ucfirst($status)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td><input type="text" name="categories" value="<?php echo esc_attr(wp_strip_all_tags(wc_get_product_category_list($product->get_id(), ',', '', ''))); ?>"></td>
                <td><input type="text" name="tags" value="<?php echo esc_attr(wp_strip_all_tags(wc_get_product_tag_list($product->get_id(), ',', '', ''))); ?>"></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
