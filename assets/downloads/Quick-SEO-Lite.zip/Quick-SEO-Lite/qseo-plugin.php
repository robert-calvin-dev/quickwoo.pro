<?php
/**
 * Plugin Name: Quick SEO Lite
 * Description: Spreadsheet-style SEO editor for WooCommerce products (Lite version: max 5 rows).
 * Version: 1.0
 * Author: Robert Calvin
 * Text Domain: quick-seo-lite
 */

if (!defined('ABSPATH')) exit;

// Add admin menu
add_action('admin_menu', function () {
  add_submenu_page(
    'woocommerce',
    esc_html__('Quick SEO Lite', 'quick-seo-lite'),
    esc_html__('Quick SEO Lite', 'quick-seo-lite'),
    'manage_woocommerce',
    'quick-seo-lite',
    'qseo_lite_render_page'
  );
});

// Enqueue styles and scripts
add_action('admin_enqueue_scripts', function ($hook) {
  if (strpos($hook, 'quick-seo-lite') !== false) {
    wp_enqueue_style('qseo-lite-style', plugin_dir_url(__FILE__) . 'qseo-style.css');
    wp_enqueue_script('qseo-lite-script', plugin_dir_url(__FILE__) . 'qseo-script.js', ['jquery'], null, true);
    wp_localize_script('qseo-lite-script', 'qseo_ajax', [
      'ajax_url' => admin_url('admin-ajax.php'),
      'nonce'    => wp_create_nonce('qseo_lite_nonce')
    ]);
  }
});

// Render admin page
function qseo_lite_render_page() {
  include plugin_dir_path(__FILE__) . 'qseo-template.php';
}

// AJAX Save Handler
add_action('wp_ajax_qseo_lite_save', function () {
  if (!current_user_can('manage_woocommerce') || !check_ajax_referer('qseo_lite_nonce', 'security', false)) {
    wp_send_json_error(esc_html__('Permission denied.', 'quick-seo-lite'));
  }

  parse_str(wp_unslash($_POST['data'] ?? ''), $form_data);
  $updated = 0;

  if (!empty($form_data['products']) && is_array($form_data['products'])) {
    foreach ($form_data['products'] as $product_id => $fields) {
      $pid = absint($product_id);
      if ($pid && $pid > 0) {
        update_post_meta($pid, '_qseo_focus_keyword', sanitize_text_field($fields['focus_keyword']));
        update_post_meta($pid, '_qseo_seo_title', sanitize_text_field($fields['seo_title']));
        update_post_meta($pid, '_qseo_meta_description', sanitize_textarea_field($fields['meta_description']));
        update_post_meta($pid, '_qseo_og_title', sanitize_text_field($fields['og_title']));
        update_post_meta($pid, '_qseo_og_description', sanitize_textarea_field($fields['og_description']));
        $updated++;
      }
    }
  }

  wp_send_json_success(esc_html__("Saved $updated product(s).", 'quick-seo-lite'));
});

// Frontend schema injection
add_action('wp_head', function () {
  if (is_product()) {
    global $post;
    echo "\n<!-- Quick SEO Lite Output -->\n";
    echo '<meta name="description" content="' . esc_attr(get_post_meta($post->ID, '_qseo_meta_description', true)) . '">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr(get_post_meta($post->ID, '_qseo_og_title', true)) . '">' . "\n";
    echo '<meta property="og:description" content="' . esc_attr(get_post_meta($post->ID, '_qseo_og_description', true)) . '">' . "\n";
  }
});

// Add meta box to WooCommerce product edit screen
add_action('add_meta_boxes', function () {
 add_meta_box(
   'qseo_product_seo',
   __('Quick SEO Lite', 'quick-seo-lite'),
   'qseo_lite_render_metabox',
   'product',
   'normal',
   'default'
 );
});

function qseo_lite_render_metabox($post) {
 $fields = [
   'focus_keyword'    => __('Focus Keyword', 'quick-seo-lite'),
   'seo_title'        => __('SEO Title', 'quick-seo-lite'),
   'meta_description' => __('Meta Description', 'quick-seo-lite'),
   'og_title'         => __('OG Title', 'quick-seo-lite'),
   'og_description'   => __('OG Description', 'quick-seo-lite'),
 ];

 foreach ($fields as $key => $label) {
   $value = get_post_meta($post->ID, '_qseo_' . $key, true);
   echo '<p><label><strong>' . esc_html($label) . ':</strong><br />';
   if (in_array($key, ['meta_description', 'og_description'])) {
     echo '<textarea name="qseo_' . esc_attr($key) . '" rows="3" style="width:100%;">' . esc_textarea($value) . '</textarea>';
   } else {
     echo '<input type="text" name="qseo_' . esc_attr($key) . '" value="' . esc_attr($value) . '" style="width:100%;" />';
   }
   echo '</label></p>';
 }

 echo '<p style="margin-top:10px; font-size:12px;">';
 esc_html_e('These fields are synced with the Quick SEO Lite spreadsheet view.', 'quick-seo-lite');
 echo '</p>';
}

// Save metabox values
add_action('save_post_product', function ($post_id) {
 if (!current_user_can('edit_product', $post_id)) return;
 if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

 $keys = ['focus_keyword', 'seo_title', 'meta_description', 'og_title', 'og_description'];
 foreach ($keys as $key) {
   if (isset($_POST['qseo_' . $key])) {
     $value = in_array($key, ['meta_description', 'og_description'])
       ? sanitize_textarea_field($_POST['qseo_' . $key])
       : sanitize_text_field($_POST['qseo_' . $key]);
     update_post_meta($post_id, '_qseo_' . $key, $value);
   }
 }
});
