<?php
if (!defined('ABSPATH')) exit;

$products = wc_get_products(['limit' => 5, 'orderby' => 'ID', 'order' => 'DESC']);

?>
<div class="wrap">
  <h1><?php esc_html_e('Quick SEO Lite – Spreadsheet View', 'quick-seo-lite'); ?></h1>
  <form id="qseo-form">
    <?php wp_nonce_field('qseo_lite_nonce', 'qseo_lite_nonce_field'); ?>
    <table class="wp-list-table widefat fixed striped">
      <thead>
        <tr>
          <th><?php esc_html_e('Product', 'quick-seo-lite'); ?></th>
          <th><?php esc_html_e('Focus Keyword', 'quick-seo-lite'); ?></th>
          <th><?php esc_html_e('SEO Title', 'quick-seo-lite'); ?></th>
          <th><?php esc_html_e('Meta Description', 'quick-seo-lite'); ?></th>
          <th><?php esc_html_e('OG Title', 'quick-seo-lite'); ?></th>
          <th><?php esc_html_e('OG Description', 'quick-seo-lite'); ?></th>
          <th><?php esc_html_e('Schema Output?', 'quick-seo-lite'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($products as $product) :
          $id = $product->get_id();
          ?>
          <tr>
            <td><?php echo esc_html($product->get_name()); ?></td>
            <td>
              <input type="text" name="products[<?php echo esc_attr($id); ?>][focus_keyword]"
                     value="<?php echo esc_attr(get_post_meta($id, '_qseo_focus_keyword', true)); ?>">
            </td>
            <td>
              <input type="text" name="products[<?php echo esc_attr($id); ?>][seo_title]"
                     value="<?php echo esc_attr(get_post_meta($id, '_qseo_seo_title', true)); ?>">
            </td>
            <td>
              <textarea name="products[<?php echo esc_attr($id); ?>][meta_description]"><?php echo esc_textarea(get_post_meta($id, '_qseo_meta_description', true)); ?></textarea>
            </td>
            <td>
              <input type="text" name="products[<?php echo esc_attr($id); ?>][og_title]"
                     value="<?php echo esc_attr(get_post_meta($id, '_qseo_og_title', true)); ?>">
            </td>
            <td>
              <textarea name="products[<?php echo esc_attr($id); ?>][og_description]"><?php echo esc_textarea(get_post_meta($id, '_qseo_og_description', true)); ?></textarea>
            </td>
            <td class="qseo-schema-output">
              <span><?php echo esc_html(get_post_meta($id, '_qseo_meta_description', true)) ? __('Yes', 'quick-seo-lite') : __('No', 'quick-seo-lite'); ?></span>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <p><button type="submit" class="button-primary"><?php esc_html_e('Save SEO Data', 'quick-seo-lite'); ?></button></p>
  </form>
  <div class="qseo-lite-notice">
    <p><?php esc_html_e('Unlock full SEO control with Quick SEO Pro – edit unlimited products, add schema fields, and more.', 'quick-seo-lite'); ?></p>
    <a href="https://quickwoo.pro/quick-seo-pro/" class="button button-secondary" target="_blank"><?php esc_html_e('Upgrade Now', 'quick-seo-lite'); ?></a>
  </div>
</div>
