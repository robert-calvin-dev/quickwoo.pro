=== Quick SEO Lite ===
Contributors: robertcalvin
Tags: woocommerce, seo, seo plugin, spreadsheet, open graph, meta description
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A spreadsheet-style SEO editor for WooCommerce products. Edit focus keywords, titles, meta and OG descriptions for 5 products at a time.

== Description ==

**Quick SEO Lite** lets WooCommerce store owners manage essential SEO fields in a fast, spreadsheet-style interface – no page loads, no fluff.

**Lite Version Limitations:**
- Edit up to 5 WooCommerce products at a time
- No schema customization or OG image support
- Upgrade to Pro for full capabilities

**Editable fields include:**
* Focus Keyword
* SEO Title
* Meta Description
* OG Title
* OG Description

SEO data updates via AJAX for a smoother workflow, and automatically outputs meta tags to your product pages' `<head>`.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`
2. Activate the plugin through the “Plugins” menu in WordPress
3. Navigate to **WooCommerce > Quick SEO Lite**

== Screenshots ==

1. Spreadsheet-style product SEO interface

== Frequently Asked Questions ==

= Can I edit more than 5 products? =
No. Quick SEO Lite is limited to 5 rows. Upgrade to Quick SEO Pro to unlock unlimited editing and extra features.

= Is schema support included? =
The Lite version only outputs basic Open Graph tags. Pro includes full Schema.org injection options.

== Upgrade Notice ==

Unlock full SEO control with Quick SEO Pro – unlimited product editing, schema, and social meta image fields.

== Changelog ==

= 1.0 =
* Initial release of Quick SEO Lite

