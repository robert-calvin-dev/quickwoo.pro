# 🕸️ Quick SEO Internal Link Map

A command-line tool that crawls your website, builds an internal link graph, and outputs visual and structured reports for SEO audits.

Built by [Robert Calvin](https://quickwoo.pro) as part of the Quick SEO toolkit.

---

## 🚀 Features

- Crawl your entire site recursively
- Maps all internal links between pages
- Detects silos, dead-ends, and orphan pages
- Outputs:
  - `graph.dot` (Graphviz format)
  - `links.csv` (raw edge list)
  - `orphans.txt` (pages with no inbound links)
  - `summary.txt` (site structure metrics)
  - `graph.html` (interactive force-directed map)

---

## ⚙️ Installation

### Linux/macOS:

```
git clone https://github.com/robert-calvin-dev/internal-link-map.git
cd internal-link-map
bash install.sh
```
### Windows:

```
install.bat
```

## 🧪 Usage


```
python3 main.py --url https://yourdomain.com --output ./output
```
### Options:

--url (required): The starting URL of your site (e.g., https://example.com)

--output (optional): Path to the output directory (default: ./output)

## 📂 Output Files
- File	Description
- graph.dot	Directed graph in DOT format
- links.csv	All discovered internal links
- orphans.txt	Pages with no inbound links
- summary.txt	Summary metrics (pages, links, orphans)
- graph.html	D3.js-powered interactive visualization

## 🌐 Visual Graph
Open output/graph.html after your crawl to explore how your pages connect. It shows clusters, isolated nodes, and directional flow.

### 📦 Dependencies
Install with pip3:

- requests
- beautifulsoup4
- networkx
- pydot
- tqdm

Or use:

```
pip3 install -r requirements.txt
```
## 🔒 License
MIT License — free to use, modify, and distribute.

### 👨‍💻 Author
### Robert Calvin
### [Vancouver, BC]
### 📧 robert.calvin.dev@gmail.com
### 🔗 https://quickwoo.pro
