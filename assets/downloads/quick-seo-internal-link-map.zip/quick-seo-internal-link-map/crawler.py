import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from collections import deque
from tqdm import tqdm

def is_internal_link(href, base_netloc):
    if not href or href.startswith(('mailto:', 'tel:', 'javascript:', '#')):
        return False
    parsed = urlparse(href)
    return parsed.netloc == '' or parsed.netloc == base_netloc

def normalize_url(url):
    parsed = urlparse(url)
    base = f"{parsed.scheme}://{parsed.netloc}"
    path = parsed.path.rstrip('/')
    return base + path

def crawl_site(start_url):
    visited = set()
    links = []
    queue = deque([start_url])

    base_netloc = urlparse(start_url).netloc
    session = requests.Session()
    headers = {
        'User-Agent': 'QuickSEO-Internal-Link-Map/1.0 (+https://quickwoo.pro)'
    }

    with tqdm(total=0, unit='page') as progress:
        while queue:
            current_url = queue.popleft()
            norm_url = normalize_url(current_url)
            if norm_url in visited:
                continue

            try:
                res = session.get(current_url, headers=headers, timeout=10)
                res.raise_for_status()
            except Exception:
                continue

            visited.add(norm_url)
            progress.total = len(visited)
            progress.update(1)
            progress.set_description(f"Crawling {norm_url}")

            soup = BeautifulSoup(res.text, 'html.parser')
            for a in soup.find_all('a', href=True):
                href = a['href'].strip()
                if not is_internal_link(href, base_netloc):
                    continue

                abs_link = urljoin(current_url, href)
                norm_link = normalize_url(abs_link)

                if norm_link not in visited and norm_link not in queue:
                    queue.append(norm_link)

                links.append((norm_url, norm_link))

    return visited, links
