import networkx as nx

def build_graph(pages, links):
    G = nx.DiGraph()

    # Add all pages as nodes
    for page in pages:
        G.add_node(page)

    # Add directed edges for links
    for source, target in links:
        if source in G and target in G:
            G.add_edge(source, target)

    return G
