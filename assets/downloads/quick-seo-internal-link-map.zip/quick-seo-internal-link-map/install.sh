#!/bin/bash
echo "🔧 Installing Quick SEO Internal Link Map dependencies..."

# Optional: set up virtual environment
python3 -m venv venv
source venv/bin/activate

pip3 install --upgrade pip
pip3 install requests beautifulsoup4 networkx pydot tqdm

echo "✅ Installation complete."
echo "👉 Run with: python3 main.py --url https://example.com --output ./output"
