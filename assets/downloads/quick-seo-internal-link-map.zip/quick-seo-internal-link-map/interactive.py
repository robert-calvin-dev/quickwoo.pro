import os
import json

def generate_interactive_html(graph, output_dir):
    # Prepare nodes and edges
    nodes = [{"id": node} for node in graph.nodes()]
    edges = [{"source": u, "target": v} for u, v in graph.edges()]

    graph_data = {
        "nodes": nodes,
        "links": edges
    }

    data_json = json.dumps(graph_data)

    # Load HTML template
    template_path = os.path.join(os.path.dirname(__file__), 'templates', 'graph_template.html')
    with open(template_path, 'r', encoding='utf-8') as f:
        template = f.read()

    # Inject graph data
    escaped_json = data_json.replace('\\', '\\\\').replace('`', '\\`')
    html_output = template.replace("%GRAPH_DATA%", escaped_json)


    output_path = os.path.join(output_dir, 'graph.html')
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html_output)
