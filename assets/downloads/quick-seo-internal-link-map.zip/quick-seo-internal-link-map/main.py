import argparse
import os
from crawler import crawl_site
from graphbuilder import build_graph
from output import write_outputs
from interactive import generate_interactive_html

def main():
    parser = argparse.ArgumentParser(description="🕸️ Internal Link Structure Mapper")
    parser.add_argument('--url', required=True, help='Starting URL (e.g. https://example.com)')
    parser.add_argument('--output', default='./output', help='Directory to save graph and reports')
    args = parser.parse_args()

    start_url = args.url.rstrip('/')
    output_dir = args.output.rstrip('/')

    os.makedirs(output_dir, exist_ok=True)

    print(f"🌐 Crawling site: {start_url}")
    all_pages, all_links = crawl_site(start_url)

    print(f"🔗 Building graph with {len(all_pages)} pages and {len(all_links)} links")
    graph = build_graph(all_pages, all_links)

    print(f"💾 Writing output files to: {output_dir}")
    write_outputs(graph, all_pages, all_links, output_dir)

    print(f"🌈 Generating interactive HTML visualization")
    generate_interactive_html(graph, output_dir)

    print("✅ Done! Open graph.html to view the structure.")

if __name__ == '__main__':
    main()
