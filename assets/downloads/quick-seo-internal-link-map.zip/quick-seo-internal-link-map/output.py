import os
import csv

def write_outputs(graph, pages, links, output_dir):
    write_dot(graph, output_dir)
    write_csv(links, output_dir)
    write_orphans(graph, output_dir)
    write_summary(graph, output_dir)

def write_dot(graph, output_dir):
    try:
        import pydot
        from networkx.drawing.nx_pydot import write_dot
    except ImportError:
        print("⚠️ Warning: 'pydot' not installed. Skipping DOT output.")
        return

    dot_path = os.path.join(output_dir, "graph.dot")
    write_dot(graph, dot_path)

def write_csv(links, output_dir):
    csv_path = os.path.join(output_dir, "links.csv")
    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["From", "To"])
        writer.writerows(links)

def write_orphans(graph, output_dir):
    orphans = [n for n in graph.nodes if graph.in_degree(n) == 0]
    orphan_path = os.path.join(output_dir, "orphans.txt")
    with open(orphan_path, 'w', encoding='utf-8') as f:
        for url in orphans:
            f.write(url + "\n")

def write_summary(graph, output_dir):
    num_pages = graph.number_of_nodes()
    num_links = graph.number_of_edges()
    orphan_count = len([n for n in graph.nodes if graph.in_degree(n) == 0])
    avg_degree = sum(dict(graph.degree()).values()) / float(num_pages)

    summary_path = os.path.join(output_dir, "summary.txt")
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write("Quick SEO Internal Link Map - Summary Report\n")
        f.write(f"Total Pages: {num_pages}\n")
        f.write(f"Total Links: {num_links}\n")
        f.write(f"Average Degree: {avg_degree:.2f}\n")
        f.write(f"Orphan Pages: {orphan_count}\n")
