from urllib.parse import urlparse
import hashlib

def get_slug(url):
    """Return the last part of the URL path (for label display)"""
    parsed = urlparse(url)
    slug = parsed.path.rstrip('/').split('/')[-1]
    return slug if slug else '/'

def strip_domain(url):
    """Return only path portion of URL"""
    parsed = urlparse(url)
    return parsed.path.rstrip('/')

def url_to_filename(url):
    """Convert URL into safe filename string"""
    return hashlib.md5(url.encode()).hexdigest() + '.html'

def get_domain(url):
    return urlparse(url).netloc.lower()
