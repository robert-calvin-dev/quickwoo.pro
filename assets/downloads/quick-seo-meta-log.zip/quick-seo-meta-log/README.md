# 🧠 Quick SEO Meta Log by Quick Woo

A Python-based command-line tool that crawls **every internal page** of a website, extracts the `<title>` and `<meta name="description">` content, and saves it all into a clean, structured CSV file.

Ideal for SEO audits, competitor analysis, or content gap checks.

---

## 🚀 How to Use

### 1. 📦 Install Dependencies

We recommend using a virtual environment:

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows use: venv\Scripts\activate
pip3 install -r requirements.txt
```

`requirements.txt` now includes both standard and Selenium-based dependencies.

If you're using the JS-powered version (`scraper-js.py`), you'll also need ChromeDriver installed and in your PATH:  
➡️ [https://sites.google.com/chromium.org/driver/](https://sites.google.com/chromium.org/driver/)

---

### 2. 🧰 Run the Scraper

#### 🖱️ One-Click Setup (Recommended for Beginners)

- On **Windows**, double-click `install.bat`  
- On **macOS/Linux**, run this from terminal:

```bash
chmod +x install.sh
./install.sh
```

These will:
- Create a virtual environment  
- Install dependencies  
- Launch the standard scraper interactively

---

#### 🔹 Power Users (Command-Line Mode)

Standard scraper:
```bash
python3 scraper.py --url "https://example.com" --output "example.csv"
```

JavaScript scraper:
```bash
python3 scraper-js.py --url "https://example.com" --output "example.csv"
```

---

#### 🔸 Interactive Mode

Just run either script without arguments:

```bash
python3 scraper.py       # For static sites
python3 scraper-js.py    # For JavaScript sites
```

It will ask:

```
Enter homepage URL to crawl: https://example.com
Enter output CSV file name (or press Enter for 'output.csv'): mysite.csv
```

---

### 3. 📑 Output CSV Format

Your CSV will include the following columns:

| URL | Title | Meta Description |
|-----|-------|------------------|

- If any fields are missing on a page, they’ll be left **blank**, not skipped.

---

## ✅ Features

- 🔍 Full recursive crawl of all internal links  
- 🤖 Respects `robots.txt` (safe for ethical scraping)  
- 📄 Exports all found meta titles & descriptions  
- ⏳ Includes pages even if meta tags are missing  
- 📢 Real-time terminal logging  
- 🛠️ Beginner-friendly + CLI-friendly dual-mode support  
- 🧠 Optional JavaScript support using Selenium for dynamic content

---

## 💡 Notes

- 🌐 External domains are ignored  
- ⏱️ Request timeout is set to 10 seconds per page  
- 🧭 `robots.txt` is checked before each request  
- 🧼 URLs are cleaned of fragments and duplicates  
- ⚙️ JavaScript scraping uses `scraper-js.py` and requires ChromeDriver

---

## 🔒 Legal Stuff

This tool is provided as-is for **educational and ethical SEO use only**.  
Do **not** use it to scrape sites without permission.

---

© Robert Calvin — [QuickWoo.pro](https://quickwoo.pro)  
Built with caffeine, contempt for repetitive work, and pure Python.
