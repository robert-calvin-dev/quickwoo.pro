#!/bin/bash

echo "📦 Setting up Quick SEO Meta Log environment..."

# Step 1: Create venv
python3 -m venv venv || { echo "❌ Python3 not found."; exit 1; }

# Step 2: Activate venv
source venv/bin/activate

# Step 3: Install requirements
pip3 install -r requirements.txt || { echo "❌ Failed to install packages."; exit 1; }

# Step 4: Run the scraper
echo "🚀 Launching scraper.py..."
python3 scraper.py