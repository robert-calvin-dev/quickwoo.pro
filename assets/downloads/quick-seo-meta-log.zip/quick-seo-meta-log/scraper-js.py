#!/usr/bin/env python3

import csv
import time
import argparse
from urllib.parse import urljoin, urlparse
from collections import deque
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

visited = set()

def is_valid_url(url):
    parsed = urlparse(url)
    return bool(parsed.netloc) and bool(parsed.scheme)

def get_domain(url):
    parsed = urlparse(url)
    return f"{parsed.scheme}://{parsed.netloc}"

def clean_url(url):
    url = url.split('#')[0].rstrip('/')
    return url

def setup_driver():
    options = Options()
    options.add_argument("--headless=new")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    driver = webdriver.Chrome(options=options)
    return driver

def crawl_site(start_url, output_file):
    domain = get_domain(start_url)
    queue = deque([start_url])
    driver = setup_driver()

    results = []

    print(f"\n🔍 Starting JS-rendered crawl on: {start_url}\n")

    while queue:
        url = queue.popleft()
        url = clean_url(url)
        if url in visited:
            continue

        try:
            driver.get(url)
            time.sleep(2)  # allow JS to load
        except Exception as e:
            print(f"[ERROR] Failed to load: {url}")
            continue

        visited.add(url)
        title = driver.title.strip() if driver.title else ''
        description = ''
        try:
            desc_el = driver.find_element(By.XPATH, "//meta[@name='description']")
            description = desc_el.get_attribute("content").strip()
        except:
            pass

        print(f"[+] {url} — Title: {'Yes' if title else 'No'}, Desc: {'Yes' if description else 'No'}")
        results.append([url, title, description])

        links = driver.find_elements(By.TAG_NAME, "a")
        for link in links:
            href = link.get_attribute("href")
            if not href or not href.startswith("http"):
                continue
            href = clean_url(href)
            if href.startswith(domain) and href not in visited:
                queue.append(href)

    driver.quit()

    # Write CSV
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["URL", "Title", "Meta Description"])
        writer.writerows(results)

    print(f"\n✅ Crawl complete. {len(results)} pages saved to {output_file}")

def main():
    parser = argparse.ArgumentParser(description="Quick SEO Meta Log with JavaScript rendering")
    parser.add_argument("--url", help="Homepage URL to crawl")
    parser.add_argument("--output", help="CSV file to save results")
    args = parser.parse_args()

    if not args.url:
        args.url = input("Enter homepage URL to crawl: ").strip()
    if not args.output:
        args.output = input("Enter output CSV file name (default: output.csv): ").strip() or "output.csv"

    if not is_valid_url(args.url):
        print("❌ Invalid URL. Must start with https:// or http://")
        return

    crawl_site(args.url, args.output)

if __name__ == "__main__":
    main()
