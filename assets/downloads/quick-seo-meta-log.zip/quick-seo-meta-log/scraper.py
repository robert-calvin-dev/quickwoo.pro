#!/usr/bin/env python3
# scraper.py

import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urljoin
import csv
import argparse
import time
from collections import deque
from tqdm import tqdm
import os
import re
import urllib.robotparser

visited = set()
internal_links = set()

def is_valid_url(url):
    parsed = urlparse(url)
    return bool(parsed.netloc) and bool(parsed.scheme)

def get_domain(url):
    parsed = urlparse(url)
    return parsed.scheme + "://" + parsed.netloc

def clean_url(url):
    # Strip trailing slashes and fragments
    url = re.sub(r'#.*$', '', url)
    url = url.rstrip('/')
    return url

def get_robots_parser(base_url):
    rp = urllib.robotparser.RobotFileParser()
    rp.set_url(urljoin(base_url, "/robots.txt"))
    try:
        rp.read()
    except:
        pass  # treat as permissive
    return rp

def get_meta_data(url):
    try:
        headers = {'User-Agent': 'QuickSEO MetaScraper'}
        response = requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')
        title = soup.title.string.strip() if soup.title else ''
        description_tag = soup.find('meta', attrs={'name': 'description'})
        description = description_tag['content'].strip() if description_tag and 'content' in description_tag.attrs else ''
        return title, description
    except Exception as e:
        return '', ''

def crawl_site(start_url, output_path):
    domain = get_domain(start_url)
    rp = get_robots_parser(domain)
    queue = deque([start_url])

    csv_rows = []

    print(f"\n🔍 Starting crawl on: {start_url}\n")
    time.sleep(1)

    while queue:
        current_url = queue.popleft()
        current_url = clean_url(current_url)

        if current_url in visited:
            continue

        visited.add(current_url)

        obey_robots = False  # Change to True if needed
        if obey_robots and not rp.can_fetch("*", current_url):
            print(f"[robots.txt] Skipping disallowed: {current_url}")
            continue

        try:
            headers = {'User-Agent': 'QuickSEO MetaScraper'}
            response = requests.get(current_url, headers=headers, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
        except Exception as e:
            print(f"[ERROR] Failed to load: {current_url}")
            continue

        title, description = get_meta_data(current_url)
        print(f"[+] {current_url}  —  Title: {'Yes' if title else 'No'}  Desc: {'Yes' if description else 'No'}")

        csv_rows.append([current_url, title, description])

        for a_tag in soup.find_all('a', href=True):
            href = a_tag['href'].strip()

            # Skip junk links
            if href.startswith('#') or href.startswith('mailto:') or href.startswith('tel:') or 'javascript:' in href:
                continue

            # Resolve full URL and normalize
            joined_url = urljoin(current_url, href)
            joined_url = clean_url(joined_url)

            # Skip external domains
            if not joined_url.startswith(domain):
                continue

            # Queue if not already visited
            if joined_url not in visited:
                queue.append(joined_url)

    # Write CSV
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['URL', 'Title', 'Description'])
        writer.writerows(csv_rows)

    print(f"\n✅ Crawl complete. {len(csv_rows)} pages saved to {output_path}")

def main():
    parser = argparse.ArgumentParser(description='QuickSEO: Meta Title & Description Scraper')
    parser.add_argument('--url', help='Homepage URL to start crawling from')
    parser.add_argument('--output', help='Output CSV file name')
    args = parser.parse_args()

    # Prompt interactively if missing
    if not args.url:
        args.url = input("Enter homepage URL to crawl: ").strip()
    if not args.output:
        args.output = input("Enter output CSV file name (or press Enter for 'output.csv'): ").strip()
        if not args.output:
            args.output = "output.csv"

    if not is_valid_url(args.url):
        print("❌ Invalid URL. Please include https:// or http://")
        return

    crawl_site(args.url, args.output)

if __name__ == '__main__':
    main()
