# 🧠 Quick SEO Schema Builder

A modular Python CLI tool to extract, validate, fix, and build JSON-LD schema for SEO auditing and content optimization.

Built by [Robert Calvin](https://quickwoo.pro) as part of the Quick SEO suite.

---

## 🚀 Features

- 🔍 **Extract** schema from any webpage (JSON-LD + Microdata)
- ✅ **Validate** schema for SEO compliance using Google-style rules
- 🛠️ **Fix** broken or missing fields via interactive CLI
- 🏗️ **Build** schema from scratch using pre-built templates
- 💾 Save all output to `output/` as clean, copy-paste–ready JSON

---

## 🛠️ Install

```bash
git clone https://github.com/robert-calvin-dev/quick-seo-schema.git
cd quick-seo-schema
pip3 install -r requirements.txt
```
Python 3.8+ recommended.

## 📦 Usage
### 🔎 Extract + Validate from URL
```bash
python3 main.py --url "https://example.com"
```

## 🛠️ Fix Schema (from test_schema.json)
```bash
python3 fixer.py
```

## 🏗️ Build Schema from Scratch
```bash
python3 builder.py
```
## 📂 Output Files
All fixed or built schema are saved to:

```
output/fixed-schema-*.json
output/built-schema-*.json
```

## 🔮 Upcoming Features
 - CLI flag to load schema from file

 - Schema injection preview

 - Auto-suggestions for missing field values

 - Bulk audit mode for multiple URLs

### 👨‍💻 Author
### Robert Calvin
### https://quickwoo.pro
### robert.calvin.dev@gmail.com