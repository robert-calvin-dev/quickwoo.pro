# builder.py

import json
import os
from datetime import datetime
from rich import print
from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table

from validator import REQUIRED_FIELDS_BY_TYPE

console = Console()


def select_schema_type():
    types = list(REQUIRED_FIELDS_BY_TYPE.keys())

    table = Table(title="Schema Types")
    table.add_column("ID", justify="right", style="cyan")
    table.add_column("Type", style="magenta")

    for i, t in enumerate(types, start=1):
        table.add_row(str(i), t)

    console.print(table)

    while True:
        try:
            choice = int(Prompt.ask("Choose schema type [1-{}]".format(len(types))))
            if 1 <= choice <= len(types):
                return types[choice - 1]
            else:
                print("[red]Invalid selection. Try again.[/red]")
        except ValueError:
            print("[red]Please enter a number.[/red]")


def prompt_for_fields(schema_type):
    answers = {}
    fields = REQUIRED_FIELDS_BY_TYPE.get(schema_type, [])

    print(f"\n[bold green]Enter values for required fields:[/bold green]")

    for field in fields:
        value = input(f"  ➤ {field}: ").strip()
        if value:
            answers[field] = value

    # Always inject context/type
    answers["@context"] = "https://schema.org"
    answers["@type"] = schema_type

    return answers


def save_built_schema(schema_obj):
    if not os.path.exists("output"):
        os.makedirs("output")

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"output/built-schema-{timestamp}.json"
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(schema_obj, f, indent=2)

    print(f"\n[bold green]💾 Schema saved to:[/bold green] {filename}")


def build_schema():
    print("\n[bold blue]🛠️ Quick SEO Schema Builder[/bold blue]")
    schema_type = select_schema_type()
    values = prompt_for_fields(schema_type)

    print("\n[green]✅ Schema built successfully:[/green]")
    print(json.dumps(values, indent=2))

    save_built_schema(values)


if __name__ == "__main__":
    build_schema()
