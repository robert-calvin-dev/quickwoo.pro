# extractor.py

import requests
from bs4 import BeautifulSoup
import json
import re


def fetch_html(url):
    """Fetch HTML from a given URL."""
    headers = {
        "User-Agent": "QuickSEO-SchemaBot/1.0 (https://quickwoo.pro/tools/schema-builder)"
    }
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        print(f"[ERROR] Failed to fetch URL: {e}")
        return None


def extract_jsonld(soup):
    """Extract JSON-LD schema blocks from <script type="application/ld+json"> tags."""
    jsonld_blocks = []
    for tag in soup.find_all("script", type="application/ld+json"):
        try:
            cleaned = tag.string.strip()
            # Handle multiple objects or arrays
            parsed = json.loads(cleaned)
            if isinstance(parsed, list):
                jsonld_blocks.extend(parsed)
            else:
                jsonld_blocks.append(parsed)
        except Exception as e:
            print(f"[WARN] Could not parse JSON-LD: {e}")
    return jsonld_blocks


def extract_microdata(soup):
    """Extract simplified Microdata blocks."""
    microdata = []
    for item in soup.select("[itemscope]"):
        item_type = item.get("itemtype", "")
        props = {}
        for prop in item.select("[itemprop]"):
            key = prop.get("itemprop")
            if prop.name == "meta":
                value = prop.get("content")
            else:
                value = prop.text.strip()
            props[key] = value
        microdata.append({"@type": item_type.split("/")[-1], **props})
    return microdata


def extract_schema(url):
    """Main extractor function."""
    html = fetch_html(url)
    if not html:
        return {"jsonld": [], "microdata": []}

    soup = BeautifulSoup(html, "lxml")
    jsonld = extract_jsonld(soup)
    microdata = extract_microdata(soup)
    return {
        "jsonld": jsonld,
        "microdata": microdata
    }


if __name__ == "__main__":
    test_url = input("Enter a URL to extract schema from: ").strip()
    result = extract_schema(test_url)
    
    print("\n[JSON-LD SCHEMA BLOCKS FOUND]:", len(result["jsonld"]))
    for block in result["jsonld"]:
        print(json.dumps(block, indent=2))

    print("\n[Microdata BLOCKS FOUND]:", len(result["microdata"]))
    for block in result["microdata"]:
        print(json.dumps(block, indent=2))
