# fixer.py

import json
import os
from datetime import datetime
from rich import print
from rich.prompt import Prompt, Confirm
from rich.table import Table

from validator import validate_schema_block


def fix_single_schema_block(block):
    """
    Prompt user to fix a broken schema block via CLI.
    Returns the fixed version.
    """
    print("\n[bold yellow]🛠️ Entering Fix Mode for Block[/bold yellow]")
    print(json.dumps(block, indent=2))

    issues = validate_schema_block(block)
    if not issues:
        print("[green]✅ No issues found in this block.[/green]")
        return block

    print("\n[red]❌ Issues found:[/red]")
    for issue in issues:
        print(f" - {issue}")

    for field in ["@type", "name", "url", "description", "@id", "logo", "telephone", "address"]:
        current = block.get(field, "")
        if not current or Confirm.ask(f"[cyan]Missing or empty field '{field}'. Do you want to edit it?[/cyan]"):
            new_value = Prompt.ask(f"  ➤ Enter value for [bold]{field}[/bold]", default=current or "")
            if new_value.strip():
                block[field] = new_value.strip()

    print("\n[green]✅ Fixed schema block preview:[/green]")
    print(json.dumps(block, indent=2))
    return block


def fix_all_blocks(schema_blocks):
    """
    Iterate through list of schema blocks, prompting user to fix each.
    Returns list of repaired blocks.
    """
    fixed = []
    for i, block in enumerate(schema_blocks):
        print(f"\n[bold]Fixing Schema Block {i + 1}[/bold]")
        fixed_block = fix_single_schema_block(block)
        fixed.append(fixed_block)
    return fixed


def save_fixed_schema(blocks):
    """
    Saves fixed schema to file.
    """
    if not os.path.exists("output"):
        os.makedirs("output")

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"output/fixed-schema-{timestamp}.json"
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(blocks, f, indent=2)

    print(f"\n[bold green]💾 Fixed schema saved to:[/bold green] {filename}")


if __name__ == "__main__":
    # Test mode only
    try:
        with open("test_schema.json", "r", encoding="utf-8") as f:
            raw = json.load(f)
            blocks = raw if isinstance(raw, list) else [raw]
            fixed = fix_all_blocks(blocks)
            save_fixed_schema(fixed)

    except Exception as e:
        print(f"[red]ERROR:[/red] {e}")
