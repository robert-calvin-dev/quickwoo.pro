echo "🔧 Installing Quick SEO Schema Toolkit dependencies..."
python3 -m pip install --upgrade pip
pip3 install -r requirements.txt

echo "✅ Installation complete. Run 'python3 main.py --url https://example.com' to begin."