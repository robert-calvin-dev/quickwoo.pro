# main.py

import argparse
import json
from extractor import extract_schema
from validator import validate_all, print_validation_results


def run_extraction_and_validation(url):
    print(f"[INFO] Extracting schema from: {url}")
    result = extract_schema(url)

    total_jsonld = len(result["jsonld"])
    total_micro = len(result["microdata"])

    print(f"\n[SUMMARY]")
    print(f"  JSON-LD blocks found: {total_jsonld}")
    print(f"  Microdata blocks found: {total_micro}")

    if total_jsonld:
        print("\n[VALIDATION – JSON-LD Blocks]")
        validation_results = validate_all(result["jsonld"])
        print_validation_results(validation_results)
    else:
        print("\n[WARNING] No JSON-LD found to validate.")

    # Optional: Show Microdata
    if total_micro:
        print("\n[MICRODATA BLOCKS – Raw Output]")
        for i, md in enumerate(result["microdata"], start=1):
            print(f"\n--- Microdata Block {i} ---")
            print(json.dumps(md, indent=2))


def main():
    parser = argparse.ArgumentParser(description="Quick SEO Schema Validator CLI")
    parser.add_argument('--url', type=str, required=True, help='URL of the page to scan')

    args = parser.parse_args()
    run_extraction_and_validation(args.url)


if __name__ == "__main__":
    main()
