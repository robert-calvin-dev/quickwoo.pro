# validator.py

import json
from jsonschema import validate, Draft7Validator, exceptions as jsonschema_exceptions

# Common simplified validation rules for SEO-critical schema types
REQUIRED_FIELDS_BY_TYPE = {
    "Organization": ["@context", "@type", "name", "url", "logo"],
    "LocalBusiness": ["@context", "@type", "name", "address", "telephone"],
    "Article": ["@context", "@type", "headline", "author", "datePublished"],
    "Product": ["@context", "@type", "name", "offers"],
    "FAQPage": ["@context", "@type", "mainEntity"]
}


def validate_schema_block(schema_block):
    """
    Validates a single JSON-LD schema block using basic checks + required fields per type.
    Returns list of issues (empty if clean).
    """
    issues = []

    if not isinstance(schema_block, dict):
        issues.append("Schema block is not a valid JSON object.")
        return issues

    if "@type" not in schema_block:
        issues.append("Missing @type field.")
        return issues

    schema_type = schema_block.get("@type")
    required_fields = REQUIRED_FIELDS_BY_TYPE.get(schema_type, [])

    for field in required_fields:
        if field not in schema_block:
            issues.append(f"Missing required field: {field}")

    # Additional sanity checks
    for critical_field in ["name", "url", "description"]:
        if critical_field in schema_block:
            if not schema_block[critical_field]:
                issues.append(f"Field '{critical_field}' is empty.")

    if "@id" in schema_block:
        if not schema_block["@id"].startswith("http"):
            issues.append("@id should be a full URL.")

    return issues


def validate_all(schema_blocks):
    """
    Validate a list of JSON-LD schema blocks.
    Returns a list of (index, type, issues[]) for each block.
    """
    results = []
    for i, block in enumerate(schema_blocks):
        schema_type = block.get("@type", "Unknown")
        issues = validate_schema_block(block)
        results.append({
            "index": i + 1,
            "type": schema_type,
            "issues": issues
        })
    return results


def print_validation_results(results):
    """Print validation results to console."""
    for result in results:
        print(f"\n[Schema Block {result['index']}]: Type: {result['type']}")
        if result["issues"]:
            for issue in result["issues"]:
                print(f"  ❌ {issue}")
        else:
            print("  ✅ No issues found.")


if __name__ == "__main__":
    # Standalone test mode
    try:
        with open("test_schema.json", "r", encoding="utf-8") as f:
            raw = json.load(f)
            if isinstance(raw, dict):
                blocks = [raw]
            elif isinstance(raw, list):
                blocks = raw
            else:
                raise ValueError("Invalid JSON structure.")

        results = validate_all(blocks)
        print_validation_results(results)

    except Exception as e:
        print(f"[ERROR] Could not validate schema: {e}")
