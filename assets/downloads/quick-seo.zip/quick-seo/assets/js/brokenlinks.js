jQuery(document).ready(function ($) {
 $('#scan-broken-links').on('click', function () {
     $('#broken-links-results').html('🔍 Scanning...');

     $.post(ajaxurl, {
         action: 'quick_seo_scan_links',
     }, function (response) {
         if (!response.success || !Object.keys(response.data).length) {
             $('#broken-links-results').html('✅ No broken links found.');
             return;
         }

         let html = '<table class="wp-list-table widefat"><thead><tr><th>Broken Link</th><th>Found In</th><th>Redirect To</th><th>Action</th></tr></thead><tbody>';
         $.each(response.data, function (link, source) {
             html += `
                 <tr>
                     <td>${link}</td>
                     <td><a href="${source}" target="_blank">${source}</a></td>
                     <td><input type="text" data-from="${link}" class="redirect-to" placeholder="/new-path" /></td>
                     <td><button class="button add-redirect" data-from="${link}">Add Redirect</button></td>
                 </tr>
             `;
         });
         html += '</tbody></table>';

         $('#broken-links-results').html(html);
     });
 });

 $(document).on('click', '.add-redirect', function () {
     const from = $(this).data('from');
     const to = $(`input[data-from="${from}"]`).val();

     $.post(ajaxurl, {
         action: 'quick_seo_add_redirect',
         from: from,
         to: to
     }, function (response) {
         alert(response.success ? '✅ Redirect added' : '❌ ' + response.data);
     });
 });

 $(document).on('click', '.remove-redirect', function () {
     const from = $(this).data('from');

     $.post(ajaxurl, {
         action: 'quick_seo_remove_redirect',
         from: from
     }, function (response) {
         location.reload();
     });
 });
});
