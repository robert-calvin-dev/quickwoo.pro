jQuery(document).ready(function ($) {

    function getVal(name) {
        return $(`[name="${name}"]`).val() || "";
    }

    function buildDefaultTemplates() {
        return {
            WebPage: {
                "@context": "https://schema.org",
                "@type": "WebPage",
                "name": getVal('_quickseo_seo_title'),
                "description": getVal('_quickseo_meta_description'),
                "url": window.location.href
            },
            Article: {
                "@context": "https://schema.org",
                "@type": "Article",
                "headline": getVal('_quickseo_seo_title'),
                "author": { "@type": "Person", "name": "Robert Calvin" },
                "datePublished": "",
                "publisher": { "@type": "Organization", "name": "QuickWoo" }
            },
            BlogPosting: {
                "@context": "https://schema.org",
                "@type": "BlogPosting",
                "headline": getVal('_quickseo_seo_title'),
                "author": { "@type": "Person", "name": "Robert Calvin" },
                "datePublished": "",
                "publisher": { "@type": "Organization", "name": "QuickWoo" }
            },
            NewsArticle: {
                "@context": "https://schema.org",
                "@type": "NewsArticle",
                "headline": getVal('_quickseo_seo_title'),
                "datePublished": "",
                "author": { "@type": "Person", "name": "Robert Calvin" },
                "publisher": { "@type": "Organization", "name": "QuickWoo" }
            },
            Product: {
                "@context": "https://schema.org",
                "@type": "Product",
                "name": getVal('_quickseo_seo_title'),
                "description": getVal('_quickseo_meta_description'),
                "sku": getVal('_sku'),
                "brand": { "@type": "Brand", "name": getVal('_brand') }
            },
            Offer: {
                "@context": "https://schema.org",
                "@type": "Offer",
                "price": getVal('_price'),
                "priceCurrency": "USD",
                "availability": "https://schema.org/InStock",
                "itemOffered": { "@type": "Product", "name": getVal('_quickseo_seo_title') }
            },
            Person: {
                "@context": "https://schema.org",
                "@type": "Person",
                "name": getVal('_quickseo_seo_title'),
                "jobTitle": getVal('_job_title'),
                "sameAs": []
            },
            Organization: {
                "@context": "https://schema.org",
                "@type": "Organization",
                "name": getVal('_organization_name'),
                "url": getVal('_organization_url'),
                "logo": getVal('_organization_logo')
            },
            Event: {
                "@context": "https://schema.org",
                "@type": "Event",
                "name": getVal('_quickseo_seo_title'),
                "startDate": getVal('_event_start'),
                "location": {
                    "@type": "Place",
                    "name": getVal('_event_location'),
                    "address": getVal('_event_address')
                }
            },
            LocalBusiness: {
                "@context": "https://schema.org",
                "@type": "LocalBusiness",
                "name": getVal('_quickseo_seo_title'),
                "address": getVal('_business_address'),
                "telephone": getVal('_business_phone')
            },
            Service: {
                "@context": "https://schema.org",
                "@type": "Service",
                "name": getVal('_quickseo_seo_title'),
                "description": getVal('_quickseo_meta_description'),
                "provider": { "@type": "Organization", "name": "QuickWoo" }
            },
            FAQPage: {
                "@context": "https://schema.org",
                "@type": "FAQPage",
                "mainEntity": [
                    {
                        "@type": "Question",
                        "name": getVal('_faq_question'),
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": getVal('_faq_answer')
                        }
                    }
                ]
            },
            HowTo: {
                "@context": "https://schema.org",
                "@type": "HowTo",
                "name": getVal('_quickseo_seo_title'),
                "step": [
                    {
                        "@type": "HowToStep",
                        "text": getVal('_howto_step')
                    }
                ]
            }
        };
    }

    // expose for use elsewhere if needed
    window.quickSeoSchemaDefaults = buildDefaultTemplates;

    function loadSchemaTemplate(type) {
        $.post(ajaxurl, {
            action: 'quick_seo_load_schema_template',
            nonce: quickSeo.nonce,
            type: type
        }, function (response) {
            if (response.success) {
                $('#schema-json').val(response.data.schema);
            } else {
                const fallback = buildDefaultTemplates()[type]
                    ? JSON.stringify(buildDefaultTemplates()[type], null, 2)
                    : '';
                $('#schema-json').val(fallback);
            }
        });
    }

    $('#schema-type').on('change', function () {
        const type = $(this).val();
        loadSchemaTemplate(type);
    });

    $('#save-schema').on('click', function () {
        const type = $('#schema-type').val();
        const schema = $('#schema-json').val();

        $.post(ajaxurl, {
            action: 'quick_seo_save_schema_template',
            nonce: quickSeo.nonce,
            type: type,
            schema: schema
        }, function (response) {
            const msg = response.success ? '✅ Schema saved.' : '❌ Error: ' + response.data;
            $('#schema-feedback').text(msg);
        });
    });

    // Load template on first view
    loadSchemaTemplate($('#schema-type').val());
});
