jQuery(document).ready(function ($) {
 function loadSchemaTemplate(type) {
     $.post(ajaxurl, {
         action: 'quick_seo_load_schema_template',
         nonce: quickSeo.nonce,
         type: type
     }, function (response) {
         if (response.success) {
             $('#schema-json').val(response.data.schema);
         } else {
             $('#schema-json').val('');
         }
     });
 }

 $('#schema-type').on('change', function () {
     const type = $(this).val();
     loadSchemaTemplate(type);
 });

 $('#save-schema').on('click', function () {
     const type = $('#schema-type').val();
     const schema = $('#schema-json').val();

     $.post(ajaxurl, {
         action: 'quick_seo_save_schema_template',
         nonce: quickSeo.nonce,
         type: type,
         schema: schema
     }, function (response) {
         const msg = response.success ? '✅ Schema saved.' : '❌ Error: ' + response.data;
         $('#schema-feedback').text(msg);
     });
 });

 // Load default on first visit
 loadSchemaTemplate($('#schema-type').val());
});
