jQuery(document).ready(function ($) {
  $('#quick-seo-save-categories').on('submit', function (e) {
    e.preventDefault();

    const seoData = {};

    $('table tbody tr').each(function () {
      const termId = $(this).data('id');
      seoData[termId] = {};

      $(this).find('input').each(function () {
        const name = $(this).attr('name');
        const val = $(this).val();
        const key = name.split('[')[0];
        seoData[termId][key] = val;
      });
    });

    $.ajax({
      method: 'POST',
      url: quickSeoCategories.ajaxurl,
      data: {
        action: 'quick_seo_save_categories',
        nonce: quickSeoCategories.nonce,
        seo_data: seoData
      },
      success: function (response) {
        if (response.success) {
          alert('✅ Category SEO saved!');
        } else {
          alert('❌ Error: ' + response.data);
        }
      },
      error: function () {
        alert('❌ AJAX request failed.');
      }
    });
  });
});
