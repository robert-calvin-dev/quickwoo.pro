jQuery(document).ready(function ($) {
 $('#quick-seo-save-pages').on('submit', function (e) {
     e.preventDefault();

     const seoData = {};

     $('table tbody tr').each(function () {
         const postId = $(this).data('id');
         seoData[postId] = {};

         $(this).find('input').each(function () {
             const name = $(this).attr('name');
             const val = $(this).val();
             const key = name.split('[')[0];
             seoData[postId][key] = val;
         });
     });

     $.ajax({
         method: 'POST',
         url: ajaxurl,
         data: {
             action: 'quick_seo_save_pages',
             nonce: quickSeo.nonce,
             seo_data: seoData
         },
         success: function (response) {
             if (response.success) {
                 alert('✅ SEO data saved!');
             } else {
                 alert('❌ Error: ' + response.data);
             }
         },
         error: function () {
             alert('❌ AJAX request failed.');
         }
     });
 });
});
