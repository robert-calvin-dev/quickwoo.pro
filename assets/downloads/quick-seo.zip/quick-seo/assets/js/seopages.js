jQuery(document).ready(function ($) {
    $('#quick-seo-save-pages').on('submit', function (e) {
        e.preventDefault();

        const seoData = {};

        $('table tbody tr').each(function () {
            const postId = $(this).data('id');
            seoData[postId] = {};

            $(this).find('input').each(function () {
                    const name = $(this).attr('name'); // e.g. "seo_title[123]"
                    const val = $(this).val();
                    const match = name.match(/^(.+)\[(\d+)\]$/);

                    if (match) {
                        const key = match[1];       // "seo_title"
                        const pid = match[2];       // "123"

                        if (!seoData[pid]) seoData[pid] = {};
                        seoData[pid][key] = val;
                    }
            });
        });

        $.ajax({
            method: 'POST',
            url: quickSeoPages.ajaxurl, // ✅ must match localized name
            data: {
                action: 'quick_seo_save_pages',
                nonce: quickSeoPages.nonce, // ✅ must match localized name
                seo_data: seoData
            },
            success: function (response) {
                if (response.success) {
                    alert('✅ SEO data saved!');
                    location.reload(); // ← Optional: trigger reload
                } else {
                    alert('❌ Error: ' + response.data);
                }
            },
            error: function () {
                alert('❌ AJAX request failed.');
            }
        });
    });
});

