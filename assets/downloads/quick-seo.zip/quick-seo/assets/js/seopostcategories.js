jQuery(document).ready(function ($) {
  $('#quick-seo-save-post-categories').on('submit', function (e) {
    e.preventDefault();

    const seoData = {};

    $('table tbody tr').each(function () {
      const termId = $(this).data('id');
      seoData[termId] = {};

      $(this).find('input').each(function () {
        const name = $(this).attr('name');
        const val = $(this).val();
        const key = name.split('[')[0];
        seoData[termId][key] = val;
      });
    });

    $.ajax({
      method: 'POST',
      url: quickSeoPostCategories.ajaxurl,
      data: {
        action: 'quick_seo_save_post_categories',
        nonce: quickSeoPostCategories.nonce,
        seo_data: seoData
      },
      success: function (response) {
        alert(response.success ? '✅ Post category SEO saved!' : '❌ Error: ' + response.data);
      },
      error: function () {
        alert('❌ AJAX request failed.');
      }
    });
  });
});
