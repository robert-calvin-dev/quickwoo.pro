jQuery(document).ready(function ($) {
 $('#quick-seo-save-posts').on('submit', function (e) {
     e.preventDefault();

     const seoData = {};

     $('table tbody tr').each(function () {
         const postId = $(this).data('id');
         seoData[postId] = {};

         $(this).find('input').each(function () {
                    const name = $(this).attr('name'); // e.g. "seo_title[123]"
                    const val = $(this).val();
                    const match = name.match(/^(.+)\[(\d+)\]$/);

                    if (match) {
                        const key = match[1];       // "seo_title"
                        const pid = match[2];       // "123"

                        if (!seoData[pid]) seoData[pid] = {};
                        seoData[pid][key] = val;
                    }
         });
     });

     $.ajax({
         method: 'POST',
         url: quickSeoPosts.ajaxurl,
         data: {
             action: 'quick_seo_save_posts', // ⬅️ Match PHP handler
             nonce: quickSeoPosts.nonce,
             seo_data: seoData
         },
         success: function (response) {
             if (response.success) {
                 alert('✅ Post SEO data saved!');
             } else {
                 alert('❌ Error: ' + response.data);
             }
         },
         error: function () {
             alert('❌ AJAX request failed.');
         }
     });
 });
});
