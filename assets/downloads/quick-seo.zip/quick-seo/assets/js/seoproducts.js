jQuery(document).ready(function ($) {
 $('#quick-seo-save-products').on('submit', function (e) {
     e.preventDefault();

     const seoData = {};

     $('table tbody tr').each(function () {
         const postId = $(this).data('id');
         seoData[postId] = {};

         $(this).find('input').each(function () {
             const name = $(this).attr('name');
             const val = $(this).val();
             const key = name.split('[')[0];
             seoData[postId][key] = val;
         });
     });

     $.ajax({
         method: 'POST',
         url: quickSeoProducts.ajaxurl,
         data: {
             action: 'quick_seo_save_products', // ⬅️ Match PHP handler
             nonce: quickSeoProducts.nonce,
             seo_data: seoData
         },
         success: function (response) {
             if (response.success) {
                 alert('✅ Product SEO data saved!');
             } else {
                 alert('❌ Error: ' + response.data);
             }
         },
         error: function () {
             alert('❌ AJAX request failed.');
         }
     });
 });
});