jQuery(document).ready(function ($) {
    $('#quick-seo-save-product-tags').on('submit', function (e) {
        e.preventDefault();

        const seoData = {};

        $('table tbody tr').each(function () {
            const termId = $(this).data('id');
            seoData[termId] = {};

      $(this).find('input').each(function () {
        const name = $(this).attr('name');
        const val = $(this).val();
        const key = name.split('[')[0];
        seoData[termId][key] = val;
      });
    });

        $.ajax({
            method: 'POST',
            url: quickSeoProductTags.ajaxurl,
            data: {
                action: 'quick_seo_save_product_tags',
                nonce: quickSeoProductTags.nonce,
                seo_data: seoData
            },
            success: function (res) {
                if (res.success) {
                    alert('✅ Product tag SEO saved!');
                    location.reload();
                } else {
                    alert('❌ Error: ' + res.data);
                }
            },
            error: function () {
                alert('❌ AJAX request failed.');
            }
        });
    });
});
