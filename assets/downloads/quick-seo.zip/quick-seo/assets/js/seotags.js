jQuery(document).ready(function ($) {
  $('#quick-seo-save-tags').on('submit', function (e) {
    e.preventDefault();

    const seoData = {};

    $('table tbody tr').each(function () {
      const termId = $(this).data('id');
      seoData[termId] = {};

      $(this).find('input').each(function () {
        const name = $(this).attr('name');
        const val = $(this).val();
        const key = name.split('[')[0];
        seoData[termId][key] = val;
      });
    });

    $.ajax({
      method: 'POST',
      url: quickSeoTags.ajaxurl,
      data: {
        action: 'quick_seo_save_tags',
        nonce: quickSeoTags.nonce,
        seo_data: seoData
      },
      success: function (response) {
        if (response.success) {
          alert('✅ Tag SEO saved!');
        } else {
          alert('❌ Error: ' + response.data);
        }
      },
      error: function () {
        alert('❌ AJAX request failed.');
      }
    });
  });
});
