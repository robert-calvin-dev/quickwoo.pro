jQuery(document).ready(function ($) {
 $('#quick-seo-generate-sitemap').on('click', function () {
     $.post(ajaxurl, {
         action: 'quick_seo_generate_sitemap',
         nonce: quickSeo.nonce
     }, function (response) {
         const msg = response.success ? '✅ ' + response.data : '❌ ' + response.data;
         $('#sitemap-feedback').text(msg);
     });
 });
});
