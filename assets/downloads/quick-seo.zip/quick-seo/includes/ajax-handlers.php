<?php
// AJAX hooks
add_action('wp_ajax_quick_seo_save_pages', 'quick_seo_save_pages_ajax');
add_action('wp_ajax_quick_seo_save_schema_template', 'quick_seo_save_schema_template');
add_action('wp_ajax_quick_seo_load_schema_template', 'quick_seo_load_schema_template');
add_action('wp_ajax_quick_seo_save_posts', 'quick_seo_save_posts_ajax');
add_action('wp_ajax_quick_seo_save_products', 'quick_seo_save_products_ajax'); // ← This was missing too!
add_action('wp_ajax_quick_seo_save_categories', 'quick_seo_save_categories_ajax'); // ← ADD THIS
add_action('wp_ajax_quick_seo_save_tags', 'quick_seo_save_tags_ajax'); // ← AND THIS
add_action('wp_ajax_quick_seo_save_robots', 'quick_seo_save_robots');
add_action('wp_ajax_quick_seo_generate_sitemap', 'quick_seo_generate_sitemap_ajax');
add_action('wp_ajax_quick_seo_scan_links', 'quick_seo_scan_links');
add_action('wp_ajax_quick_seo_add_redirect', 'quick_seo_add_redirect');
add_action('wp_ajax_quick_seo_remove_redirect', 'quick_seo_remove_redirect');

