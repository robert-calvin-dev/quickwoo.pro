<?php

// Settings page
function quick_seo_render_canonical_page() {
    $default = get_option('quickseo_global_canonical', 'default');
    ?>
    <div class="wrap">
        <h1>Canonical URL Settings</h1>
        <p>Set the default canonical behavior for all content. This helps prevent duplicate content issues.</p>

        <form method="post" id="quick-seo-canonical-settings">
            <label><input type="radio" name="canonical_mode" value="default" <?= $default === 'default' ? 'checked="checked"' : '' ?>> Use WordPress permalink (default)</label><br>
            <label><input type="radio" name="canonical_mode" value="clean" <?= $default === 'clean' ? 'checked="checked"' : '' ?>> Strip query parameters (clean)</label><br>
            <label><input type="radio" name="canonical_mode" value="custom" <?= $default === 'custom' ? 'checked="checked"' : '' ?>> Use custom field per post</label><br><br>

            <input type="submit" class="button button-primary" value="💾 Save Settings">
            <?php wp_nonce_field('quick_seo_canonical_nonce', 'canonical_nonce'); ?>
        </form>

        <div id="canonical-feedback" style="margin-top:10px;"></div>
    </div>
    <?php
}

// Save canonical setting
function quick_seo_save_canonical_settings() {
    if (!isset($_POST['canonical_nonce']) || !wp_verify_nonce($_POST['canonical_nonce'], 'quick_seo_canonical_nonce')) return;
    if (!current_user_can('manage_options')) return;

    $mode = sanitize_text_field($_POST['canonical_mode'] ?? 'default');
    update_option('quickseo_global_canonical', $mode);

    echo '<div class="updated"><p>✅ Canonical settings saved.</p></div>';
}
add_action('admin_init', 'quick_seo_save_canonical_settings');
