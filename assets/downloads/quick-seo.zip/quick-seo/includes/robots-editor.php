<?php

function quick_seo_render_robots_editor() {
    $path = ABSPATH . 'robots.txt';
    $content = file_exists($path) ? file_get_contents($path) : "User-agent: *\nDisallow:\n";

    echo '<div class="wrap">';
    echo '<h1>robots.txt Editor</h1>';
    echo '<p>Edit the contents of your site\'s <code>robots.txt</code> file below.</p>';
    echo '<textarea id="quick-seo-robots" rows="15" style="width:100%; font-family: monospace;">' . esc_textarea($content) . '</textarea>';
    echo '<p><button class="button button-primary" id="save-robots">💾 Save robots.txt</button></p>';
    echo '<div id="robots-feedback" style="margin-top:10px;"></div>';
    echo '</div>';
}

function quick_seo_save_robots() {
    check_ajax_referer('quick_seo_schema_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $content = $_POST['content'] ?? '';
    $path = ABSPATH . 'robots.txt';

    if (!is_writable(ABSPATH)) {
        wp_send_json_error('Root directory not writable');
    }

    $written = file_put_contents($path, $content);
    if ($written === false) {
        wp_send_json_error('Failed to write robots.txt');
    }

    wp_send_json_success();
}
