<?php
// Add the Quick SEO meta box to all relevant post types
function quick_seo_add_meta_boxes() {
    $post_types = ['page', 'post', 'product'];
    foreach ($post_types as $type) {
        add_meta_box(
            'quick_seo_meta_box',
            'Quick SEO',
            'quick_seo_render_meta_box',
            $type,
            'normal',
            'default'
        );
    }
}

// Render the meta box HTML
function quick_seo_render_meta_box($post) {
    wp_nonce_field('quick_seo_meta_box_nonce', 'quick_seo_meta_box_nonce');

    $fields = [
        'focus_keyword'       => 'Focus Keyword',
        'secondary_keyword'   => 'Secondary Keyword',
        'seo_title'           => 'SEO Title',
        'meta_description'    => 'Meta Description',
        'og_title'            => 'OG Title',
        'og_description'      => 'OG Description',
        'og_type'             => 'OG Type',
        'og_image'            => 'OG Image URL',
        'twitter_title'       => 'Twitter Title',
        'twitter_description' => 'Twitter Description',
        'twitter_image'       => 'Twitter Image',
        'schema'              => 'Schema JSON',
        'longtail_keyword'    => 'Longtail Keyword',
        'canonical_override'  => 'Canonical Override',
        'robots'              => 'Robots Directive',
        'sitemap'             => 'Include in Sitemap? (yes/no)',
    ];

    // Schema dropdown options
    $schema_templates = [
        'WebPage', 'Article', 'BlogPosting', 'NewsArticle', 'Product', 'Offer',
        'Person', 'Organization', 'Event', 'LocalBusiness', 'Service',
        'FAQPage', 'HowTo'
    ];

    echo '<table class="form-table quick-seo-meta">';
foreach ($fields as $key => $label) {
    $meta_key = '_quickseo_' . $key;
    $value = get_post_meta($post->ID, $meta_key, true);

    echo "<tr><th><label for='{$meta_key}'>{$label}</label></th><td>";

    if ($key === 'robots') {
        echo "<select id='{$meta_key}' name='{$meta_key}' class='widefat'>";
        foreach (['index, follow', 'noindex, follow', 'index, nofollow', 'noindex, nofollow'] as $option) {
            echo "<option value='" . esc_attr($option) . "'" . selected($value, $option, false) . ">" . esc_html($option) . "</option>";
        }
        echo "</select>";
    } elseif ($key === 'sitemap') {
        echo "<label><input type='checkbox' id='{$meta_key}' name='{$meta_key}' value='yes' " . checked($value, 'yes', false) . "> Include in Sitemap</label>";
    } elseif ($key === 'schema') {
        echo "<select id='{$meta_key}' name='{$meta_key}' class='widefat'>";
        echo "<option value=''>— Select Schema Type —</option>";
        foreach ($schema_templates as $type) {
            $selected = selected($value, $type, false);
            echo "<option value='" . esc_attr($type) . "' $selected>" . esc_html($type) . "</option>";
        }
        echo "</select>";
    } else {
        $placeholder = $key === 'canonical_override' ? 'Leave empty to use default' : '';
        echo "<input type='text' id='{$meta_key}' name='{$meta_key}' value='" . esc_attr($value) . "' class='widefat' placeholder='{$placeholder}' />";
    }

    echo "</td></tr>";
}

    echo '</table>';
}



// Save the meta data when post is saved
function quick_seo_save_meta_box_data($post_id) {
    if (!isset($_POST['quick_seo_meta_box_nonce']) || !wp_verify_nonce($_POST['quick_seo_meta_box_nonce'], 'quick_seo_meta_box_nonce')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    $fields = [
        'focus_keyword',
        'secondary_keyword',
        'seo_title',
        'meta_description',
        'og_title',
        'og_description',
        'og_type',
        'og_image',
        'twitter_title',
        'twitter_description',
        'twitter_image',
        'schema',
        'longtail_keyword',
        'canonical_override',
        'robots',
        'sitemap'
    ];

    foreach ($fields as $key) {
        $meta_key = '_quickseo_' . $key;
        if (isset($_POST[$meta_key])) {
            update_post_meta($post_id, $meta_key, sanitize_text_field($_POST[$meta_key]));
        }
    }
}
