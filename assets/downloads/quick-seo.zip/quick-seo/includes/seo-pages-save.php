<?php

function quick_seo_save_pages_ajax() {
    // Security check
    check_ajax_referer('quick_seo_save_pages_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    if (!isset($_POST['seo_data']) || !is_array($_POST['seo_data'])) {
        wp_send_json_error('Invalid data');
    }

    $seo_data = $_POST['seo_data'];

    foreach ($seo_data as $post_id => $fields) {
        $post_id = intval($post_id);
        foreach ($fields as $key => $value) {
            $meta_key = '_quickseo_' . sanitize_key($key);
            update_post_meta($post_id, $meta_key, sanitize_text_field($value));
        }
    }

    wp_send_json_success('SEO data saved successfully');
}
