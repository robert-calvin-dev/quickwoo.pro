<?php

function quick_seo_save_pages_ajax() {
    // Security check
    check_ajax_referer('quick_seo_save_pages_nonce', 'nonce');

    if (!current_user_can('edit_pages')) {
        wp_send_json_error('Unauthorized');
    }

    if (!isset($_POST['seo_data']) || !is_array($_POST['seo_data'])) {
        wp_send_json_error('Invalid data');
    }

    // ✅ DEBUG: log incoming data
    error_log("=== QUICK SEO SAVE DEBUG ===");
    error_log(print_r($_POST['seo_data'], true));

    $seo_data = $_POST['seo_data'];

    foreach ($seo_data as $post_id => $fields) {
        $post_id = intval($post_id);
        if (!$post_id || !is_array($fields)) continue;

        // Save regular fields
        foreach ($fields as $key => $value) {
            // Skip sitemap for now — handle it below
            if ($key === 'sitemap') continue;

            $meta_key = '_quickseo_' . sanitize_key($key);
            update_post_meta($post_id, $meta_key, sanitize_text_field($value));
        }

        // ✅ Handle sitemap separately to ensure unchecked = no
        $sitemap_flag = isset($fields['sitemap']) && $fields['sitemap'] === 'yes' ? 'yes' : 'no';
        update_post_meta($post_id, '_quickseo_sitemap', sanitize_text_field($sitemap_flag));
    }

    wp_send_json_success('SEO data saved successfully');
}
