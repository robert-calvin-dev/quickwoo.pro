<?php
function quick_seo_save_post_categories_ajax() {
    check_ajax_referer('quick_seo_save_post_categories_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    if (!isset($_POST['seo_data']) || !is_array($_POST['seo_data'])) {
        wp_send_json_error('Invalid data');
    }

    $seo_data = $_POST['seo_data'];

    foreach ($seo_data as $term_id => $fields) {
        foreach ($fields as $key => $value) {
            $meta_key = '_quickseo_' . sanitize_key($key);
            update_term_meta($term_id, $meta_key, sanitize_text_field($value));
        }
    }

    wp_send_json_success('Post category SEO data saved');
}
