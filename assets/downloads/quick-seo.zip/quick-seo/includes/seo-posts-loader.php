<?php
function quick_seo_load_posts_table(): void {
    if (!current_user_can('manage_options')) return;

    $args = [
        'post_type'      => 'post',
        'post_status'    => ['publish', 'draft'],
        'numberposts'    => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ];

    $posts = get_posts($args);
    $data = [];

    foreach ($posts as $post) {
        $meta = get_post_meta($post->ID);
        $data[] = [
            'ID'                 => $post->ID,
            'Title'              => $post->post_title,
            'FocusKeyword'       => $meta['_quickseo_focus_keyword'][0] ?? '',
            'SecondaryKeyword'   => $meta['_quickseo_secondary_keyword'][0] ?? '',
            'SEOTitle'           => $meta['_quickseo_seo_title'][0] ?? '',
            'MetaDescription'    => $meta['_quickseo_meta_description'][0] ?? '',
            'OGTitle'            => $meta['_quickseo_og_title'][0] ?? '',
            'OGDescription'      => $meta['_quickseo_og_description'][0] ?? '',
            'OGType'             => $meta['_quickseo_og_type'][0] ?? '',
            'OGImage'            => $meta['_quickseo_og_image'][0] ?? '',
            'TwitterTitle'       => $meta['_quickseo_twitter_title'][0] ?? '',
            'TwitterDescription' => $meta['_quickseo_twitter_description'][0] ?? '',
            'TwitterImage'       => $meta['_quickseo_twitter_image'][0] ?? '',
            'Schema'             => $meta['_quickseo_schema'][0] ?? '',
            'LongtailKeyword'    => $meta['_quickseo_longtail_keyword'][0] ?? '',
        ];
    }

    $context = 'posts';
    include QUICK_SEO_PLUGIN_DIR . 'templates/seo-page-table.php';
}
