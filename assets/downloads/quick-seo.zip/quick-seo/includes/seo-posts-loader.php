<?php
function quick_seo_load_posts_table(): void {
    if (!current_user_can('manage_options')) return;

    $args = [
        'post_type'      => 'post',
        'post_status'    => ['publish', 'draft'],
        'numberposts'    => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ];

    $posts = get_posts($args);
    $data = [];

    foreach ($posts as $post) {
        $meta = get_post_meta($post->ID);
        $data[] = [
            'ID'                  => $post->ID,
            'title'               => $post->post_title, // lowercase to avoid confusion
            'focus_keyword'       => $meta['_quickseo_focus_keyword'][0] ?? '',
            'secondary_keyword'   => $meta['_quickseo_secondary_keyword'][0] ?? '',
            'seo_title'           => $meta['_quickseo_seo_title'][0] ?? '',
            'meta_description'    => $meta['_quickseo_meta_description'][0] ?? '',
            'og_title'            => $meta['_quickseo_og_title'][0] ?? '',
            'og_description'      => $meta['_quickseo_og_description'][0] ?? '',
            'og_type'             => $meta['_quickseo_og_type'][0] ?? '',
            'og_image'            => $meta['_quickseo_og_image'][0] ?? '',
            'twitter_title'       => $meta['_quickseo_twitter_title'][0] ?? '',
            'twitter_description' => $meta['_quickseo_twitter_description'][0] ?? '',
            'twitter_image'       => $meta['_quickseo_twitter_image'][0] ?? '',
            'schema'              => $meta['_quickseo_schema'][0] ?? '',
            'longtail_keyword'    => $meta['_quickseo_longtail_keyword'][0] ?? '',
            'robots'             => $meta['_quickseo_robots'][0] ?? '',
            'sitemap'            => $meta['_quickseo_sitemap'][0] ?? '',
        ];

    }

    $context = 'posts';
    include QUICK_SEO_PLUGIN_DIR . 'templates/seo-posts-table.php';
}
