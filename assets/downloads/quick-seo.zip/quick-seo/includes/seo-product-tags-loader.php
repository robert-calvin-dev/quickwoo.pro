<?php
function quick_seo_load_product_tags_table(): void {
    if (!current_user_can('manage_options')) return;

    $terms = get_terms([
        'taxonomy'   => 'product_tag',
        'hide_empty' => false,
        'orderby'    => 'name',
        'order'      => 'ASC',
        'fields'     => 'all',
    ]);

    $data = [];

    foreach ($terms as $term) {
        $term_id = is_object($term) ? $term->term_id : ($term['term_id'] ?? null);
        $term_name = is_object($term) ? $term->name : ($term['name'] ?? '');

        if (!$term_id) continue;

        $meta = get_term_meta($term_id);
        $data[] = [
            'ID'                 => $term_id,
            'title'              => $term_name,
            'focus_keyword'       => $meta['_quickseo_focus_keyword'][0] ?? '',
            'secondary_keyword'   => $meta['_quickseo_secondary_keyword'][0] ?? '',
            'seo_title'           => $meta['_quickseo_seo_title'][0] ?? '',
            'meta_description'    => $meta['_quickseo_meta_description'][0] ?? '',
            'og_title'            => $meta['_quickseo_og_title'][0] ?? '',
            'og_description'      => $meta['_quickseo_og_description'][0] ?? '',
            'og_type'             => $meta['_quickseo_og_type'][0] ?? '',
            'og_image'            => $meta['_quickseo_og_image'][0] ?? '',
            'twitter_title'       => $meta['_quickseo_twitter_title'][0] ?? '',
            'twitter_description' => $meta['_quickseo_twitter_description'][0] ?? '',
            'twitter_image'       => $meta['_quickseo_twitter_image'][0] ?? '',
            'schema'              => $meta['_quickseo_schema'][0] ?? '',
            'longtail_keyword'    => $meta['_quickseo_longtail_keyword'][0] ?? '',
            'robots'             => $meta['_quickseo_robots'][0] ?? '',
            'sitemap'            => $meta['_quickseo_sitemap'][0] ?? '',
        ];
    }

    $context = 'product-tags';
    include QUICK_SEO_PLUGIN_DIR . 'templates/seo-product-tag-table.php';
}
