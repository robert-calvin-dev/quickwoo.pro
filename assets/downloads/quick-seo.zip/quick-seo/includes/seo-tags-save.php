<?php
function quick_seo_save_tags_ajax() {
    check_ajax_referer('quick_seo_save_tags_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    if (!isset($_POST['seo_data']) || !is_array($_POST['seo_data'])) {
        wp_send_json_error('Invalid data');
    }

    foreach ($_POST['seo_data'] as $term_id => $fields) {
        $term_id = intval($term_id);
        foreach ($fields as $key => $value) {
            update_term_meta($term_id, '_quickseo_' . sanitize_key($key), sanitize_text_field($value));
        }
    }

    wp_send_json_success('Tag SEO data saved.');
}
