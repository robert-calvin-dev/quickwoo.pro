<?php

function quick_seo_render_sitemap_generator() {
    ?>
    <div class="wrap">
        <h1>XML Sitemap Generator</h1>
        <p>This tool will regenerate your sitemap and save it to <code>/sitemap.xml</code> in your site root.</p>
        <button class="button button-primary" id="quick-seo-generate-sitemap">🧭 Generate Sitemap</button>
        <div id="sitemap-feedback" style="margin-top: 15px;"></div>
    </div>
    <?php
}

function quick_seo_generate_sitemap_ajax() {
    check_ajax_referer('quick_seo_schema_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $post_types = ['page', 'post', 'product'];
    $urls = [];

    foreach ($post_types as $type) {
        $args = [
            'post_type'      => $type,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids', // 🔄 optimization
        ];

        $query = new WP_Query($args);

        if ($query->have_posts()) {
            foreach ($query->posts as $post_id) {
                $urls[] = get_permalink($post_id);
            }
        }
        wp_reset_postdata();
    }

    $xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    $xml .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";

    foreach ($urls as $url) {
        $xml .= "  <url>\n";
        $xml .= "    <loc>" . htmlspecialchars($url, ENT_XML1, 'UTF-8') . "</loc>\n"; // ✅ correct XML escaping
        $xml .= "    <lastmod>" . date('c') . "</lastmod>\n";
        $xml .= "    <changefreq>weekly</changefreq>\n";
        $xml .= "    <priority>0.8</priority>\n";
        $xml .= "  </url>\n";
    }

    $xml .= "</urlset>";

    $path = ABSPATH . 'sitemap.xml';

    if (!is_writable(ABSPATH)) {
        wp_send_json_error('Root directory is not writable');
    }

    $result = file_put_contents($path, $xml);

    if ($result === false) {
        wp_send_json_error('Failed to write sitemap.xml');
    }

    wp_send_json_success('Sitemap generated successfully!');
}
