<?php
// 🔧 Adds the top-level admin menu page
function quick_seo_register_menu() {
    add_menu_page(
        'Quick SEO',
        'Quick SEO',
        'manage_options',
        'quick-seo',
        'quick_seo_render_dashboard',
        'dashicons-chart-line',
        26
    );

    $submenus = [
        'Pages'             => 'quick-seo-pages',
        'Posts'             => 'quick-seo-posts',
        'Products'          => 'quick-seo-products',
        'Product Categories'=> 'quick-seo-categories',
        'Post Tags'         => 'quick-seo-tags',
        'Product Tags'      => 'quick-seo-product-tags',
        'Post Categories'   => 'quick-seo-post-categories',
        'Schema'            => 'quick-seo-schema',
        'Canonical'         => 'quick-seo-canonical',
        'Redirects'         => 'quick-seo-redirects',
        'Sitemaps'          => 'quick-seo-sitemaps',
        'Robots'            => 'quick-seo-robots',
    ];

    foreach ($submenus as $label => $slug) {
        add_submenu_page(
            'quick-seo',
            $label,
            $label,
            'manage_options',
            $slug,
            'quick_seo_render_subpage'
        );
    }
}

// 🔧 Renders the top-level Quick SEO dashboard
function quick_seo_render_dashboard() {
    ?>
    <div class="wrap quick-seo-dashboard">
        <h1 style="margin-bottom: 10px;">🎉 Welcome to Quick SEO</h1>
        <p style="font-size: 1.1em; margin-bottom: 30px;">You’ve unlocked full-stack SEO control. Use the tools below to dominate search rankings across your WordPress + WooCommerce site.</p>

        <div class="quick-seo-grid">
            <?php
            $cards = [
                ['Pages', 'Spreadsheet SEO editor for all pages.', 'Focus + secondary keywords, meta, OG, schema, longtail.'],
                ['Posts', 'Bulk SEO for WordPress posts.', 'Same format as Pages.'],
                ['Products', 'Optimize WooCommerce products.', 'Add offer schema, product OG, and longtails.'],
                ['Product Categories', 'Edit SEO for product categories.', 'Includes category type column.'],
                ['Post Tags', 'SEO control for blog tags.', 'Supports meta, keywords, and schema.'],
                ['Product Tags', 'WooCommerce tag SEO editor.', 'Great for niche term ranking.'],
                ['Post Categories', 'Edit SEO for blog categories.', 'Categorical longtail support.'],
                ['Schema', 'Build & manage schema types.', 'WebPage, Product, Person, Service, and more.'],
                ['Canonical', 'Global + page-specific canonical rules.', 'Helps prevent duplicate content.'],
                ['Redirects', 'Fix broken links + set redirects.', 'Track 404s, manage redirection.'],
                ['Sitemaps', 'Generate XML sitemaps.', 'Includes all indexed content types.'],
                ['Robots', 'robots.txt file editor.', 'Control crawl behavior directly.'],
            ];

            foreach ($cards as $card) {
                $slug = strtolower(str_replace(' ', '-', $card[0]));
                $url = admin_url("admin.php?page=quick-seo-$slug");
                echo "
                <div class='quick-seo-card'>
                    <h3>{$card[0]}</h3>
                    <ul>
                        <li>{$card[1]}</li>
                        <li>{$card[2]}</li>
                    </ul>
                    <a href='$url' class='button-primary'>Open {$card[0]}</a>
                </div>";
            }
            ?>
        </div>
    </div>
    <?php
}

