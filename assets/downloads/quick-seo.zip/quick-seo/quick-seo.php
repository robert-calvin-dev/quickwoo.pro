<?php
/*
Plugin Name: Quick SEO
Plugin URI: https://quickwoo.pro
Description: A full-stack WordPress + WooCommerce SEO engine with spreadsheet-style bulk editing, schema injection, and total control over metadata.
Version: 3.0.0
Author: Robert Calvin
Author URI: https://robertcalvin.pro
License: GPLv2 or later
Text Domain: quick-seo
*/

// ─────────────────────────────────────────────
// 🔐 SECURITY: Prevent direct file access
if (!defined('ABSPATH')) exit;

// ─────────────────────────────────────────────
// 🔧 DEFINE CONSTANTS
define('QUICK_SEO_VERSION', '3.0.0');
define('QUICK_SEO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('QUICK_SEO_PLUGIN_URL', plugin_dir_url(__FILE__));

// ─────────────────────────────────────────────
// 📦 INCLUDE CORE FILES
require_once QUICK_SEO_PLUGIN_DIR . 'includes/top-level-page.php';
require_once QUICK_SEO_PLUGIN_DIR . 'includes/sub-level-pages.php';
require_once QUICK_SEO_PLUGIN_DIR . 'includes/seo-meta-box.php';
require_once QUICK_SEO_PLUGIN_DIR . 'includes/ajax-handlers.php'; // ✅ Centralizes all AJAX

// 🔄 AUTOLOAD REMAINING MODULES
$autoload_files = [
    'seo-pages-loader',
    'seo-pages-save',
    'seo-posts-loader',
    'seo-posts-save',
    'seo-products-loader',
    'seo-products-save',
    'seo-categories-loader',
    'seo-categories-save',
    'seo-tags-loader',
    'seo-tags-save',
    'seo-product-tags-loader',
    'seo-product-tags-save',
    'seo-post-categories-loader',
    'seo-post-categories-save',
    'sitemap-generator',
    'robots-editor',
    'canonical-suggestion',
    'broken-link-scanner',
    'schema-builder'
];

foreach ($autoload_files as $file) {
    require_once QUICK_SEO_PLUGIN_DIR . "includes/{$file}.php";
}

// ─────────────────────────────────────────────
// 📂 ADMIN MENUS
add_action('admin_menu', 'quick_seo_register_menu');

// ─────────────────────────────────────────────
// 🧠 METABOX SETUP
add_action('add_meta_boxes', 'quick_seo_add_meta_boxes');
add_action('save_post', 'quick_seo_save_meta_box_data');

// ─────────────────────────────────────────────
// 🎨 ADMIN SCRIPTS + STYLES
function quick_seo_enqueue_admin_assets($hook) {
    if (strpos($hook, 'quick-seo') === false) return;

    wp_enqueue_style('quick-seo-style', QUICK_SEO_PLUGIN_URL . 'assets/css/style.css');
    wp_enqueue_script('quick-seo-script', QUICK_SEO_PLUGIN_URL . 'assets/js/script.js', ['jquery'], null, true);

    $pages = [
        'pages' => 'seopages',
        'posts' => 'seoposts',
        'products' => 'seoproducts',
        'categories' => 'seocategories',
        'tags' => 'seotags',
        'product-tags' => 'seoproducttags',
        'post-categories' => 'seopostcategories'
    ];

    if (isset($_GET['page'])) {
        foreach ($pages as $slug => $jsFile) {
            if ($_GET['page'] === "quick-seo-$slug") {
                wp_enqueue_script("quick-seo-$slug", QUICK_SEO_PLUGIN_URL . "assets/js/$jsFile.js", ['jquery'], null, true);

                $jsVarName = 'quickSeo' . str_replace('-', '', ucwords($slug, '-'));
                $nonceKey = 'quick_seo_save_' . str_replace('-', '_', $slug) . '_nonce';

                wp_localize_script("quick-seo-$slug", $jsVarName, [
                    'nonce' => wp_create_nonce($nonceKey),
                    'ajaxurl' => admin_url('admin-ajax.php')
                ]);
            }
        }

        switch ($_GET['page']) {
            case 'quick-seo-robots':
                wp_enqueue_script('quick-seo-robots', QUICK_SEO_PLUGIN_URL . 'assets/js/robots.js', ['jquery'], null, true);
                break;
            case 'quick-seo-sitemaps':
                wp_enqueue_script('quick-seo-sitemap', QUICK_SEO_PLUGIN_URL . 'assets/js/sitemap.js', ['jquery'], null, true);
                break;
            case 'quick-seo-redirects':
                wp_enqueue_script('quick-seo-redirects', QUICK_SEO_PLUGIN_URL . 'assets/js/brokenlinks.js', ['jquery'], null, true);
                break;
        }
    }

    wp_localize_script('quick-seo-script', 'quickSeo', [
        'nonce' => wp_create_nonce('quick_seo_schema_nonce'),
        'ajaxurl' => admin_url('admin-ajax.php')
    ]);
}
add_action('admin_enqueue_scripts', 'quick_seo_enqueue_admin_assets');

// ─────────────────────────────────────────────
// 🧬 INJECT META INTO HEAD + LONGTAIL
add_action('wp_head', 'quick_seo_output_meta_tags', 1);
add_action('wp_footer', 'quick_seo_output_longtail_block', 100);

add_filter('pre_get_document_title', 'quick_seo_override_wp_title');
function quick_seo_override_wp_title($title) {
    if (is_singular()) {
        $custom_title = get_post_meta(get_the_ID(), '_quickseo_seo_title', true);
        if ($custom_title) {
            return $custom_title;
        }
    }
    return $title;
}

function quick_seo_output_meta_tags() {
 

    if (!is_singular()) return;
    global $post;

    $title         = get_post_meta($post->ID, '_quickseo_seo_title', true);
    $description   = get_post_meta($post->ID, '_quickseo_meta_description', true);
    $focus         = get_post_meta($post->ID, '_quickseo_focus_keyword', true);
    $secondary     = get_post_meta($post->ID, '_quickseo_secondary_keyword', true);
    $robots        = get_post_meta($post->ID, '_quickseo_robots', true);
    $sitemap_optin = get_post_meta($post->ID, '_quickseo_sitemap', true);
    $og_type        = get_post_meta($post->ID, '_quickseo_og_type', true);
    $og_image       = get_post_meta($post->ID, '_quickseo_og_image', true);
    $twitter_title  = get_post_meta($post->ID, '_quickseo_twitter_title', true);
    $twitter_desc   = get_post_meta($post->ID, '_quickseo_twitter_description', true);
    $twitter_image  = get_post_meta($post->ID, '_quickseo_twitter_image', true);
    $canonical_override = get_post_meta($post->ID, '_quickseo_canonical_override', true);
    $canonical = $canonical_override ?: get_permalink($post->ID);
    $og_title      = get_post_meta($post->ID, '_quickseo_og_title', true);
    $og_desc       = get_post_meta($post->ID, '_quickseo_og_description', true);
    $schema_type   = get_post_meta($post->ID, '_quickseo_schema', true);
    $keywords      = array_filter(array_map('trim', [$focus, $secondary]));
    $keywords_str  = implode(', ', $keywords);

    // BEGIN COMMENT BLOCK
    echo "<!-- INJECTED WITH QUICK SEO BY QUICKWOO -->\n";


    // META + STRUCTURED DATA OUTPUT

    if ($title) {
        echo '<title>' .esc_attr($title) . '</title>' . "\n";
    }

    if ($robots) {
        echo '<meta name="robots" content="' . esc_attr($robots) . '">' . "\n"; 
    }

    if ($description) {
        echo '<meta name="description" content="' . esc_attr($description) . '">' . "\n";
    }
    if ($keywords_str) {
        echo '<meta name="keywords" content="' . esc_attr($keywords_str) . '">' . "\n";
    }

    if ($sitemap_optin === 'yes') {
        echo '<link rel="sitemap" type="application/xml" href="' . esc_url(home_url('/sitemap.xml')) . '">' . "\n";
    }

    echo '<link rel="canonical" href="' . esc_url($canonical) . '">' . "\n";
    echo '<meta property="og:url" content="' . esc_url($canonical) . '">' . "\n";
    echo '<meta name="twitter:card" content="summary_large_image">' . "\n";

    if ($og_title) {
        echo '<meta property="og:title" content="' . esc_attr($og_title) . '">' . "\n";
    }
    if ($og_desc) {
        echo '<meta property="og:description" content="' . esc_attr($og_desc) . '">' . "\n";
    }

    if ($og_type) {
    echo '<meta property="og:type" content="' . esc_attr($og_type) . '">' . "\n";
}
if ($og_image) {
    echo '<meta property="og:image" content="' . esc_url($og_image) . '">' . "\n";
}
if ($twitter_title) {
    echo '<meta name="twitter:title" content="' . esc_attr($twitter_title) . '">' . "\n";
}
if ($twitter_desc) {
    echo '<meta name="twitter:description" content="' . esc_attr($twitter_desc) . '">' . "\n";
}
if ($twitter_image) {
    echo '<meta name="twitter:image" content="' . esc_url($twitter_image) . '">' . "\n";
}


    // Inject schema
    if ($schema_type) {
        $option_key = 'quickseo_schema_' . strtolower($schema_type);
        $json = get_option($option_key);
        if (!$json) {
            $json = json_encode([
                "@context" => "https://schema.org",
                "@type" => $schema_type,
                "name" => get_the_title(),
                "url" => $canonical
            ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        }
        echo "<script type=\"application/ld+json\">\n$json\n</script>\n";
    }

}


function quick_seo_output_longtail_block() {
    if (!is_singular()) return;
    global $post;
    $longtail = get_post_meta($post->ID, '_quickseo_longtail_keyword', true);
    if ($longtail) {
        echo "<div style=\"display:none;\">\n<!-- Quick SEO Longtail Injection -->\n<p>" . esc_html($longtail) . "</p>\n</div>\n";
    }
}

// ─────────────────────────────────────────────
// 🔁 REDIRECT LOGIC
add_action('template_redirect', 'quick_seo_handle_redirects');
function quick_seo_handle_redirects() {
    if (is_404()) {
        $current_path = strtok($_SERVER['REQUEST_URI'], '?');
        $redirects = get_option('quickseo_redirects', []);
        if (isset($redirects[$current_path])) {
            wp_redirect(site_url($redirects[$current_path]), 301);
            exit;
        }
    }
}

// 🧹 Strip default WP-generated <title> tag from the theme
function quick_seo_strip_wp_title_tag($buffer) {
    return preg_replace('/<title\b[^>]*>.*?<\/title>/is', '', $buffer, 1); // remove only first occurrence
}

function quick_seo_start_buffer() {
    ob_start('quick_seo_strip_wp_title_tag');
}
add_action('template_redirect', 'quick_seo_start_buffer');


remove_filter('wp_robots', 'wp_robots_max_image_preview_large');
remove_action('wp_head', 'wp_robots', 1);

add_filter('wp_robots', 'quick_seo_override_wp_robots');
function quick_seo_override_wp_robots($robots) {
    global $post;
    if (!is_singular()) return $robots;

    $robots_directive = get_post_meta($post->ID, '_quickseo_robots', true);
    if ($robots_directive) {
        // Split comma-separated values into array
        $parts = array_map('trim', explode(',', $robots_directive));
        $robots = array_fill_keys($parts, true);
    }

    return $robots;
}


