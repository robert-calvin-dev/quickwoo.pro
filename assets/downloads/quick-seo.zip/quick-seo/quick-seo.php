<?php
/*
Plugin Name: Quick SEO
Plugin URI: https://quickwoo.pro
Description: A full-stack WordPress + WooCommerce SEO engine with spreadsheet-style bulk editing, schema injection, and total control over metadata.
Version: 3.0.0
Author: Robert Calvin
Author URI: https://robertcalvin.pro
License: GPLv2 or later
Text Domain: quick-seo
*/

// ─────────────────────────────────────────────
// 🔐 SECURITY: Prevent direct file access
if (!defined('ABSPATH')) {
    exit;
}

// ─────────────────────────────────────────────
// 🔧 DEFINE CONSTANTS
define('QUICK_SEO_VERSION', '3.0.0');
define('QUICK_SEO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('QUICK_SEO_PLUGIN_URL', plugin_dir_url(__FILE__));

// ─────────────────────────────────────────────
// 📦 INCLUDE CORE FILES
require_once QUICK_SEO_PLUGIN_DIR . 'includes/top-level-page.php';
require_once QUICK_SEO_PLUGIN_DIR . 'includes/sub-level-pages.php';
require_once QUICK_SEO_PLUGIN_DIR . 'includes/seo-meta-box.php';
require_once QUICK_SEO_PLUGIN_DIR . 'includes/ajax-handlers.php';

// Optional: preload others here or defer until needed
$autoload_files = [
    'seo-pages-loader',
    'seo-pages-save',
    'seo-posts-loader',
    'seo-posts-save',
    'seo-products-loader',
    'seo-categories-loader',
    'seo-tags-loader',
    'sitemap-generator',
    'robots-editor',
    'canonical-suggestion',
    'broken-link-scanner',
    'schema-builder',
  ];

foreach ($autoload_files as $file) {
    require_once QUICK_SEO_PLUGIN_DIR . "includes/{$file}.php";

}

// ─────────────────────────────────────────────
// 📂 ADMIN MENUS
add_action('admin_menu', 'quick_seo_register_menu');

// ─────────────────────────────────────────────
// 🧠 METABOX SETUP
add_action('add_meta_boxes', 'quick_seo_add_meta_boxes');
add_action('save_post', 'quick_seo_save_meta_box_data');

// ─────────────────────────────────────────────
// 🎨 ADMIN SCRIPTS + STYLES
function quick_seo_enqueue_admin_assets($hook) {
    if (strpos($hook, 'quick-seo') === false) return;

    wp_enqueue_style('quick-seo-style', QUICK_SEO_PLUGIN_URL . 'assets/css/style.css');
    wp_enqueue_script('quick-seo-script', QUICK_SEO_PLUGIN_URL . 'assets/js/script.js', ['jquery'], null, true);

    if (isset($_GET['page'])) {
        switch ($_GET['page']) {
            case 'quick-seo-pages':
                wp_enqueue_script('quick-seo-pages', QUICK_SEO_PLUGIN_URL . 'assets/js/seopages.js', ['jquery'], null, true);
                break;
            case 'quick-seo-posts':
                wp_enqueue_script('quick-seo-posts', QUICK_SEO_PLUGIN_URL . 'assets/js/seoposts.js', ['jquery'], null, true);
                break;
            case 'quick-seo-products':
                wp_enqueue_script('quick-seo-products', QUICK_SEO_PLUGIN_URL . 'assets/js/seoproducts.js', ['jquery'], null, true);
                break;
            case 'quick-seo-categories':
                wp_enqueue_script('quick-seo-categories', QUICK_SEO_PLUGIN_URL . 'assets/js/seocategories.js', ['jquery'], null, true);
                break;
            case 'quick-seo-tags':
                wp_enqueue_script('quick-seo-tags', QUICK_SEO_PLUGIN_URL . 'assets/js/seotags.js', ['jquery'], null, true);
                break;
            case 'quick-seo-robots':
                wp_enqueue_script('quick-seo-robots', QUICK_SEO_PLUGIN_URL . 'assets/js/robots.js', ['jquery'], null, true);
                break;
            case 'quick-seo-sitemaps':
                wp_enqueue_script('quick-seo-sitemap', QUICK_SEO_PLUGIN_URL . 'assets/js/sitemap.js', ['jquery'], null, true);
                break;
            case 'quick-seo-redirects':
                wp_enqueue_script('quick-seo-redirects', QUICK_SEO_PLUGIN_URL . 'assets/js/brokenlinks.js', ['jquery'], null, true);
                break;
        }
    }

    wp_localize_script('quick-seo-pages', 'quickSeoPages', [
        'nonce' => wp_create_nonce('quick_seo_save_pages_nonce')
    ]);

    wp_localize_script('quick-seo-script', 'quickSeo', [
        'nonce' => wp_create_nonce('quick_seo_schema_nonce')
    ]);
}

add_action('admin_enqueue_scripts', 'quick_seo_enqueue_admin_assets');

// ─────────────────────────────────────────────
// 🧬 INJECT META INTO HEAD + LONGTAIL
add_action('wp_head', 'quick_seo_output_meta_tags', 1);
add_action('wp_footer', 'quick_seo_output_longtail_block', 100);

function quick_seo_output_meta_tags() {
 // Canonical URL

 if (!is_singular()) return;

 global $post;

 $fields = [
     'seo_title'        => 'title',
     'meta_description' => 'description',
     'og_title'         => 'og:title',
     'og_description'   => 'og:description',
     'og_type'          => 'og:type',
     'og_image'         => 'og:image',
     'twitter_title'    => 'twitter:title',
     'twitter_description' => 'twitter:description',
     'twitter_image'    => 'twitter:image',
 ];

 foreach ($fields as $key => $meta_tag) {
     $value = get_post_meta($post->ID, '_quickseo_' . $key, true);
     if ($value) {
         if ($meta_tag === 'title') {
             echo "<title>" . esc_html($value) . "</title>\n";
         } else {
             echo "<meta name=\"" . esc_attr($meta_tag) . "\" content=\"" . esc_attr($value) . "\">\n";
         }
     }
     $global_mode = get_option('quickseo_global_canonical', 'default');
$custom = get_post_meta($post->ID, '_quickseo_canonical_override', true);

if ($custom) {
    $canonical = esc_url($custom);
} else {
    $url = get_permalink($post->ID);
    $canonical = ($global_mode === 'clean') ? strtok($url, '?') : $url;
}

echo "<link rel=\"canonical\" href=\"$canonical\">\n";

 }

 // Open Graph + Twitter card defaults
 echo "<meta property=\"og:url\" content=\"" . esc_url(get_permalink()) . "\">\n";
 echo "<meta name=\"twitter:card\" content=\"summary_large_image\">\n";

 // Schema JSON
 $schema = get_post_meta($post->ID, '_quickseo_schema', true);
 if ($schema) {
     echo "<script type=\"application/ld+json\">\n";
     echo wp_kses_post($schema);
     echo "\n</script>\n";
 }
}

function quick_seo_output_longtail_block() {
 if (!is_singular()) return;

 global $post;

 $longtail = get_post_meta($post->ID, '_quickseo_longtail_keyword', true);
 if ($longtail) {
     echo "<div style=\"display:none;\">\n";
     echo "<!-- Quick SEO Longtail Injection -->\n";
     echo "<p>" . esc_html($longtail) . "</p>\n";
     echo "</div>\n";
 }
}

add_action('template_redirect', 'quick_seo_handle_redirects');
function quick_seo_handle_redirects() {
    if (is_404()) {
        $current_path = strtok($_SERVER['REQUEST_URI'], '?');
        $redirects = get_option('quickseo_redirects', []);

        if (isset($redirects[$current_path])) {
            wp_redirect(site_url($redirects[$current_path]), 301);
            exit;
        }
    }
}


