<?php
// templates/seo-page-table.php
?>

<div class="wrap quick-seo-table">
  <h1>Page SEO Editor</h1>
  <form id="quick-seo-save-<?= esc_attr($context ?? 'pages') ?>">
  <table class="wp-list-table widefat fixed striped">
      <thead>
        <tr>
          <th>Page Title</th>
          <th>Focus Keyword</th>
          <th>Secondary Keyword</th>
          <th>SEO Title</th>
          <th>Meta Description</th>
          <th>OG Title</th>
          <th>OG Description</th>
          <th>OG Type</th>
          <th>OG Image</th>
          <th>Twitter Title</th>
          <th>Twitter Description</th>
          <th>Twitter Image</th>
          <th>Schema</th>
          <th>Longtail Keyword</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($data as $row): ?>
          <tr data-id="<?= esc_attr($row['ID']) ?>">
            <td><?= esc_html($row['Title']) ?></td>
            <?php foreach (array_slice($row, 1) as $key => $val): ?>
              <td>
                <input type="text" name="<?= esc_attr($key) ?>[<?= $row['ID'] ?>]" value="<?= esc_attr($val) ?>" />
              </td>
            <?php endforeach; ?>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <p><button type="submit" class="button button-primary">Save All Changes</button></p>
  </form>
</div>
