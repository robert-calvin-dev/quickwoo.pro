<?php
// templates/seo-page-table.php
$schema_templates = [
  'WebPage', 'Article', 'BlogPosting', 'NewsArticle', 'Product', 'Offer',
  'Person', 'Organization', 'Event', 'LocalBusiness', 'Service',
  'FAQPage', 'HowTo'
];
?>

<div class="wrap quick-seo-table">
  <h1>Page SEO Editor</h1>
  <form id="quick-seo-save-<?= esc_attr($context) ?>">
    <table class="wp-list-table widefat fixed striped">
      <thead>
        <tr>
          <th>Name</th>
          <th>Focus Keyword</th>
          <th>Secondary Keyword</th>
          <th>SEO Title</th>
          <th>Meta Description</th>
          <th>OG Title</th>
          <th>OG Description</th>
          <th>OG Type</th>
          <th>OG Image</th>
          <th>Twitter Title</th>
          <th>Twitter Description</th>
          <th>Twitter Image</th>
          <th>Schema</th>
          <th>Longtail Keyword</th>
          <th>Robots</th>
          <th>Sitemap</th>
        </tr>
      </thead>
<tbody>
  <?php foreach ($data as $row): ?>
    <tr data-id="<?= esc_attr($row['ID']) ?>">
      <td><?= esc_html($row['title']) ?></td>
      <td><input type="text" name="focus_keyword[<?= $row['ID'] ?>]" value="<?= esc_attr($row['focus_keyword']) ?>" /></td>
      <td><input type="text" name="secondary_keyword[<?= $row['ID'] ?>]" value="<?= esc_attr($row['secondary_keyword']) ?>" /></td>
      <td><input type="text" name="seo_title[<?= $row['ID'] ?>]" value="<?= esc_attr($row['seo_title']) ?>" /></td>
      <td><input type="text" name="meta_description[<?= $row['ID'] ?>]" value="<?= esc_attr($row['meta_description']) ?>" /></td>
      <td><input type="text" name="og_title[<?= $row['ID'] ?>]" value="<?= esc_attr($row['og_title']) ?>" /></td>
      <td><input type="text" name="og_description[<?= $row['ID'] ?>]" value="<?= esc_attr($row['og_description']) ?>" /></td>
      <td><input type="text" name="og_type[<?= $row['ID'] ?>]" value="<?= esc_attr($row['og_type']) ?>" /></td>
      <td><input type="text" name="og_image[<?= $row['ID'] ?>]" value="<?= esc_attr($row['og_image']) ?>" /></td>
      <td><input type="text" name="twitter_title[<?= $row['ID'] ?>]" value="<?= esc_attr($row['twitter_title']) ?>" /></td>
      <td><input type="text" name="twitter_description[<?= $row['ID'] ?>]" value="<?= esc_attr($row['twitter_description']) ?>" /></td>
      <td><input type="text" name="twitter_image[<?= $row['ID'] ?>]" value="<?= esc_attr($row['twitter_image']) ?>" /></td>

      <td>
        <select name="schema[<?= $row['ID'] ?>]" class="quick-seo-schema-select">
          <?php foreach ($schema_templates as $type): ?>
            <option value="<?= esc_attr($type) ?>" <?= $row['schema'] === $type ? 'selected' : '' ?>>
              <?= esc_html($type) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </td>

      <td><input type="text" name="longtail_keyword[<?= $row['ID'] ?>]" value="<?= esc_attr($row['longtail_keyword']) ?>" /></td>

      <td>
        <select name="robots[<?= $row['ID'] ?>]">
          <?php foreach (['index, follow', 'noindex, follow', 'index, nofollow', 'noindex, nofollow'] as $opt): ?>
            <option value="<?= esc_attr($opt) ?>" <?= $row['robots'] === $opt ? 'selected' : '' ?>>
              <?= esc_html($opt) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </td>

      <td>
        <input type="checkbox" name="sitemap[<?= $row['ID'] ?>]" value="yes" <?= $row['sitemap'] === 'yes' ? 'checked' : '' ?> />
      </td>
    </tr>
  <?php endforeach; ?>
</tbody>

    </table>
    <p><button type="submit" class="button button-primary">Save All Changes</button></p>
  </form>
</div>
