<?php
/**
 * Plugin Name: Quick Add
 * Plugin URI: https://yourdomain.com/quick-add
 * Description: Quickly create WooCommerce products from a streamlined admin screen with SKU automation and meta controls.
 * Version: 1.0
 * Author: Robert Calvin
 * Author URI: https://yourdomain.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: Quick-Add
 */

defined('ABSPATH') || exit;

add_action('admin_menu', 'qadd_admin_menu');
function qadd_admin_menu() {
    add_menu_page('Quick Add Products', 'Quick Add', 'manage_woocommerce', 'quick-add', 'qadd_render_page', 'dashicons-products', 58);
}

add_action('admin_enqueue_scripts', 'qadd_enqueue_assets');
function qadd_enqueue_assets($hook) {
    if ($hook !== 'toplevel_page_quick-add') return;

    wp_enqueue_media();
    wp_enqueue_script('qadd_script', plugin_dir_url(__FILE__) . 'qadd-script.js', ['jquery'], '1.0', true);
    wp_enqueue_script('wc-admin-meta-boxes');
    wp_enqueue_style(
        'woocommerce_admin_styles',
        WC()->plugin_url() . '/assets/css/admin.css',
        [],
        WC_VERSION
    );
    
    wp_localize_script('qadd_script', 'qadd_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('qadd_nonce')
    ]);
}

function qadd_render_page() {
    echo '<div class="wrap"><h1>Quick Add Products</h1>
    <div style="margin-bottom:15px;padding:10px;background:#fff3cd;border:1px solid #ffeeba;border-radius:4px;color:#856404;">
      Want to add more than 2 products at a time? <a href="http://quickwoo.com/product/quick-add-pro/" target="_blank">Buy Quick Add Pro</a>
    </div>
    <form id="product-form">
        <button id="add-product" class="button add-product-row">Add Product</button>
        <div id="product-container"></div>
        <p><input type="submit" class="button-primary" value="Submit Products"></p>
    </form></div>';

    echo '<script type="text/html" id="product-template">';
    include plugin_dir_path(__FILE__) . 'qadd-template-product.php';
    echo '</script>';

    echo '<script>
    jQuery(document).on("click", ".add-product-row", function () {
        setTimeout(function () {
            jQuery(".sale_schedule").trigger("click");
            jQuery(".date-picker").datepicker();
        }, 200);
    });
    </script>';
}

add_action('wp_ajax_qadd_save_product', 'qadd_save_product');
function qadd_save_product() {
    check_ajax_referer('qadd_nonce', 'nonce');

    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    $count = count($_POST['product_name'] ?? []);
    for ($i = 0; $i < $count; $i++) {
        $product_name = sanitize_text_field(wp_unslash($_POST['product_name'][$i] ?? ''));
        $product_description = wp_kses_post(wp_unslash($_POST['product_description'][$i] ?? ''));
        $short_description = sanitize_text_field(wp_unslash($_POST['short_description'][$i] ?? ''));
        $slug = sanitize_title(wp_unslash($_POST['slug'][$i] ?? ''));
        $menu_order = intval(wp_unslash($_POST['menu_order'][$i] ?? 0));
        $status = sanitize_text_field(wp_unslash($_POST['status'][$i] ?? 'publish'));

        $post_id = wp_insert_post([
            'post_type'    => 'product',
            'post_status'  => $status,
            'post_title'   => $product_name,
            'post_content' => $product_description,
            'post_excerpt' => $short_description,
            'post_name'    => $slug,
            'menu_order'   => $menu_order
        ]);

        if (is_wp_error($post_id)) continue;

        $categories_input = isset($_POST['categories'][$i]) ? sanitize_text_field(wp_unslash($_POST['categories'][$i])) : '';
        $categories_arr = explode(',', $categories_input);
        $categories = array_filter(array_map('sanitize_text_field', $categories_arr));
        wp_set_object_terms($post_id, $categories, 'product_cat');
        
        $tags_input = isset($_POST['tags'][$i]) ? sanitize_text_field(wp_unslash($_POST['tags'][$i])) : '';
        $tags_arr = explode(',', $tags_input);
        $tags = array_filter(array_map('sanitize_text_field', $tags_arr));
        wp_set_object_terms($post_id, $tags, 'product_tag');
        

        $meta_map = [
            'sku' => 'sku',
            'gtin' => '_wc_gpf_google_product_category',
            'regular_price' => '_regular_price',
            'sale_price' => '_sale_price',
            'sale_start' => '_sale_price_dates_from',
            'sale_end' => '_sale_price_dates_to',
            'tax_status' => '_tax_status',
            'tax_class' => '_tax_class',
            'weight' => '_weight',
            'length' => '_length',
            'width' => '_width',
            'height' => '_height',
            'shipping_class' => '_shipping_class',
            'stock_status' => '_stock_status',
            'stock_quantity' => '_stock',
            'manage_stock' => '_manage_stock',
            'backorders' => '_backorders',
            'sold_individually' => '_sold_individually',
            'external_url' => '_product_url',
            'button_text' => '_button_text',
            'purchase_note' => '_purchase_note',
            'reviews_allowed' => '_reviews_allowed',
            'featured' => '_featured'
        ];

        foreach ($meta_map as $key => $meta_key) {
            $value = sanitize_text_field(wp_unslash($_POST[$key][$i] ?? ''));
            update_post_meta($post_id, $meta_key, $value);
        }

        if (isset($_POST['download_limit'][$i])) {
            update_post_meta($post_id, '_download_limit', intval($_POST['download_limit'][$i]));
        }

        if (isset($_POST['download_expiry'][$i])) {
            update_post_meta($post_id, '_download_expiry', intval($_POST['download_expiry'][$i]));
        }

        $image_url = esc_url_raw(wp_unslash($_POST['product_image'][$i] ?? ''));
        if (!empty($image_url) && filter_var($image_url, FILTER_VALIDATE_URL)) {
            $tmp = download_url($image_url);
            if (!is_wp_error($tmp)) {
                $file = ['name' => basename($image_url), 'tmp_name' => $tmp];
                $id = media_handle_sideload($file, $post_id);
                if (!is_wp_error($id)) {
                    set_post_thumbnail($post_id, $id);
                }
            }
        }

        $sale_price = sanitize_text_field(wp_unslash($_POST['sale_price'][$i] ?? ''));
        $regular_price = sanitize_text_field(wp_unslash($_POST['regular_price'][$i] ?? ''));
        $final_price = $sale_price !== '' ? $sale_price : $regular_price;
        update_post_meta($post_id, '_price', $final_price);

        $product_type = sanitize_text_field(wp_unslash($_POST['product_type'][$i] ?? 'simple'));
        switch ($product_type) {
            case 'external': $product = new WC_Product_External($post_id); break;
            case 'variable': $product = new WC_Product_Variable($post_id); break;
            case 'grouped':  $product = new WC_Product_Grouped($post_id); break;
            default:         $product = new WC_Product_Simple($post_id); break;
        }

        $product->set_virtual(!empty($_POST['virtual'][$i]));
        $product->set_downloadable(!empty($_POST['downloadable'][$i]));
        $product->set_sku(sanitize_text_field(wp_unslash($_POST['sku'][$i] ?? '')));
        $product->set_manage_stock(!empty($_POST['manage_stock'][$i]));
        $product->set_stock_quantity(intval(wp_unslash($_POST['stock_quantity'][$i] ?? 0)));
        $product->set_stock_status(sanitize_text_field(wp_unslash($_POST['stock_status'][$i] ?? 'instock')));
        $product->set_tax_class(sanitize_text_field(wp_unslash($_POST['tax_class'][$i] ?? '')));
        $product->set_tax_status(sanitize_text_field(wp_unslash($_POST['tax_status'][$i] ?? 'taxable')));

        if (method_exists($product, 'set_catalog_visibility')) {
            $product->set_catalog_visibility(sanitize_text_field(wp_unslash($_POST['catalog_visibility'][$i] ?? 'visible')));
        }

        $download_url_input = '';

if (
    isset( $_POST['download_url'] ) &&
    is_array( $_POST['download_url'] ) &&
    isset( $_POST['download_url'][ $i ] )
) {
    $maybe_urls = '';
    if (
        isset( $_POST['download_url'] ) &&
        is_array( $_POST['download_url'] ) &&
        array_key_exists( $i, $_POST['download_url'] )
    ) {
        $maybe_urls = sanitize_text_field (wp_unslash($_POST['download_url'][ $i ]));
    }
    $maybe_urls = wp_unslash( $maybe_urls );
        if ( is_array( $maybe_urls ) ) {
        $raw_urls = array_map( 'esc_url_raw', $maybe_urls );
    }
}

        
        


        if (is_array($raw_urls)) {
            $downloads = [];
            foreach ($raw_urls as $j => $raw_url) {
                $clean_url = esc_url_raw(wp_unslash($raw_url));
                if (!filter_var($clean_url, FILTER_VALIDATE_URL)) continue;
                $name_raw = '';
                if (
                    isset( $_POST['download_name'] ) &&
                    is_array( $_POST['download_name'] ) &&
                    isset( $_POST['download_name'][ $i ] ) &&
                    is_array( $_POST['download_name'][ $i ] ) &&
                    array_key_exists( $j, $_POST['download_name'][ $i ] )
                ) {
                    $name_raw = sanitize_text_field(wp_unslash($_POST['download_name'][ $i ][ $j ]));
                }
                $name_raw = sanitize_text_field( wp_unslash( $name_raw ) );
                
                                $d = new WC_Product_Download();
                $d->set_name($name);
                $d->set_file($clean_url);
                $downloads[] = $d;
            }
            $product->set_downloads($downloads);
        }

        $product->save();
    }

    wp_send_json_success();
}
