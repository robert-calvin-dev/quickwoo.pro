jQuery(document).ready(function ($) {
  const templateHtml = $('#product-template').html();

  const addProduct = () => {
    const $template = $(templateHtml);
    const index = $('.product-block').length;

    $template.find('[name]').each(function () {
      const original = $(this).attr('name');
      const updated = original.replace(/\[0\]/g, `[${index}]`);
      $(this).attr('name', updated);
    });

    $template.find('.sale-fields').hide();
    $template.find('.download-fields').hide();
    $template.find('.external-url-wrapper').hide();

    $('#product-container').append($template);
  };

  $('#add-product').on('click', function (e) {
    e.preventDefault();
    if ($('.product-block').length >= 2) {
      alert('You can only add a maximum of 2 products at once.');
      return;
    }
    addProduct();
  });

  $(document).on('click', '.upload_image_button', function (e) {
    e.preventDefault();
    const button = $(this);
    const uploader = wp.media({
      title: 'Select Image',
      button: { text: 'Use this image' },
      multiple: false
    });

    uploader.on('select', function () {
      const attachment = uploader.state().get('selection').first().toJSON();
      button.after(`
        <input type="hidden" name="product_image[]" value="${attachment.url}">
        <img src="${attachment.url}" style="max-width:100px; display:block; margin-top:5px;">
      `);
    });

    uploader.open();
  });

  $(document).on('change', '.schedule-sale-checkbox', function () {
    const container = $(this).closest('.product-block');
    const saleFields = container.find('.sale-fields');
    if ($(this).is(':checked')) {
      saleFields.slideDown();
    } else {
      saleFields.slideUp();
    }
  });

  $(document).on('change', '.downloadable-toggle', function () {
    const container = $(this).closest('.product-block');
    const downloadFields = container.find('.download-fields');
    if ($(this).is(':checked')) {
      downloadFields.slideDown();
    } else {
      downloadFields.slideUp();
    }
  });

  $(document).on('change', 'input[name="virtual[]"]', function () {
    const container = $(this).closest('.product-block');
    container.find('.shipping-fields').toggle(!this.checked);
  });

  $(document).on('click', '.add-download-file', function (e) {
    e.preventDefault();
    const $btn = $(this);
    if ($btn.data('clicked')) return;
    $btn.data('clicked', true);

    const container = $btn.closest('.download-fields');
    const block = container.find('.download-file-block:last');
    const clone = block.clone();
    clone.find('input').val('');

    const limitInput = `<label>Download Limit: <input type="number" name="download_limit[]" min="0"></label>`;
    const expiryInput = `<label>Download Expiry (days): <input type="number" name="download_expiry[]" min="0"></label>`;

    container.append(clone).append(limitInput).append(expiryInput);
  });

  $(document).on('change', 'select[name="product_type[]"]', function () {
    const container = $(this).closest('.product-block');
    container.find('.external-url-wrapper').toggle($(this).val() === 'external');
  });

  $('#product-form').on('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    formData.append('action', 'qadd_save_product');
    formData.append('nonce', qadd_ajax.nonce);

    $.ajax({
      url: qadd_ajax.ajax_url,
      method: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      dataType: 'json',
      success: function (res) {
        if (res.success) {
          alert('Products submitted successfully.');
          window.location.href = '/wp-admin/edit.php?post_type=product';
        } else {
          alert('Error submitting products.');
        }
      },
      error: function () {
        alert('Server error submitting products.');
      }
    });
  });
});

