=== Quick Add ===
Contributors: robertcalvin
Tags: woocommerce, products, quick add, admin, inventory
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Quickly create WooCommerce products from a streamlined admin screen with SKU automation, meta controls, and downloadable file support.

== Description ==

Quick Add is a lightweight WooCommerce productivity plugin that lets store admins add multiple products quickly via a single streamlined form. It supports:

* Title, description, short description
* SKU, price, sale price, sale dates
* Stock and inventory management
* Category and tag assignment
* Downloadable files with name & URL
* External/grouped/variable products
* Product image support
* Custom meta field mapping (e.g. GTIN, shipping class)

Built for speed, it uses AJAX and native WooCommerce APIs to save product data reliably.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`
2. Activate via Plugins screen.
3. Navigate to **Quick Add** in the WordPress admin menu.

== Screenshots ==

1. Admin screen for batch adding products.
2. Product entry form with fields for price, stock, downloads, etc.

== Changelog ==

= 1.0 =
* Initial release with support for basic + advanced WooCommerce product fields.

== Frequently Asked Questions ==

= Does this support downloadable files? =
Yes. You can add multiple file URLs with names per product.

= Will this work with custom post types? =
Currently supports WooCommerce `product` post type only.

= Can I add multiple products at once? =
Yes! That is the main feature. Add rows, fill data, click submit.

== Upgrade Notice ==

= 1.0 =
Initial release. Stable and ready for use.

== License ==
This plugin is licensed under the GPLv2 or later.
