<?php
defined('ABSPATH') || exit;

function qeditpro_license_is_valid() {
    $key = get_option('qeditpro_license_key');
    return !empty($key) && apply_filters('wooo_license_manager_is_valid', true, $key, 'quick-edit-pro');
}

add_action('admin_menu', function () {
    add_submenu_page(
        'edit.php?post_type=product',
        'Activate License',
        'Activate License',
        'manage_options',
        'qeditpro-license',
        'qeditpro_license_screen'
    );
});

function qeditpro_license_screen() {
    if (isset($_POST['qeditpro_license_key'])) {
        update_option('qeditpro_license_key', sanitize_text_field($_POST['qeditpro_license_key']));
        echo '<div class="updated"><p>License key saved.</p></div>';
    }

    $saved = get_option('qeditpro_license_key', '');
    echo '<div class="wrap"><h1>Activate License</h1><form method="post">
        <input type="text" name="qeditpro_license_key" value="' . esc_attr($saved) . '" size="40" />
        <button type="submit" class="button button-primary">Save License</button>
    </form></div>';
}
