<?php
if (!defined('ABSPATH')) exit;

// Hook to add settings page
add_action('admin_menu', function () {
    add_options_page('QuickWoo License', 'QuickWoo License', 'manage_options', 'quickwoo-license', 'quickwoo_license_page');
});

// Register license option
add_action('admin_init', function () {
    register_setting('quickwoo_license_group', 'quickwoo_license_key');
    register_setting('quickwoo_license_group', 'quickwoo_license_email');
});

function quickwoo_license_page() {
    ?>
    <div class="wrap">
        <h2>QuickWoo License Activation</h2>
        <form method="post" action="options.php">
            <?php
            settings_fields('quickwoo_license_group');
            do_settings_sections('quickwoo_license_group');
            ?>
            <label for="quickwoo_license_email">Email Address:</label><br>
            <input type="email" name="quickwoo_license_email" value="<?php echo esc_attr(get_option('quickwoo_license_email')); ?>" required style="width: 350px;"><br><br>
            
            <label for="quickwoo_license_key">License Key:</label><br>
            <input type="text" name="quickwoo_license_key" value="<?php echo esc_attr(get_option('quickwoo_license_key')); ?>" required style="width: 350px;"><br><br>

            <?php submit_button('Activate License'); ?>
        </form>
    </div>
    <?php
}

// License check on admin init
add_action('admin_init', function () {
    $key   = get_option('quickwoo_license_key');
    $email = get_option('quickwoo_license_email');

    if (!$key || !$email) return;

    $resp = wp_remote_post('https://api.quickwoo.pro/verify-license', [
        'timeout' => 10,
        'body' => [
            'license_key' => $key,
            'email'       => $email,
            'plugin'      => 'quick-edit'
        ]
    ]);

    if (is_wp_error($resp)) return;

    $json = json_decode(wp_remote_retrieve_body($resp), true);

    if (!isset($json['valid']) || !$json['valid']) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die('Your license key is invalid or expired. Please activate it under Settings > QuickWoo License.');
    }
});

