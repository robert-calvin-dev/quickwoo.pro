<?php
/**
 * Plugin Name: Quick Edit Pro
 * Plugin URI: https://quick-woo-app.local/product/quick-edit-pro/
 * Description: Bulk edit WooCommerce products from one screen. Unlocks all fields. Requires valid license.
 * Version: 1.0
 * Author: Robert Calvin
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: quick-edit-pro
 */

defined('ABSPATH') || exit;

require_once plugin_dir_path(__FILE__) . 'license.php';

add_action('admin_menu', 'qeditpro_register_menu');
function qeditpro_register_menu() {
    add_submenu_page(
        'edit.php?post_type=product',
        __('Quick Edit Pro', 'quick-edit-pro'),
        __('Quick Edit Pro', 'quick-edit-pro'),
        'manage_woocommerce',
        'quick-edit-pro',
        'qeditpro_render_page'
    );
}

add_action('admin_enqueue_scripts', 'qeditpro_enqueue_assets');
function qeditpro_enqueue_assets($hook) {
    if (strpos($hook, 'quick-edit-pro') === false) return;

    wp_enqueue_style('qeditpro-style', plugin_dir_url(__FILE__) . 'qedit-style.css', [], null);
    wp_enqueue_script('qeditpro-script', plugin_dir_url(__FILE__) . 'qedit-script.js', ['jquery'], null, true);
    wp_localize_script('qeditpro-script', 'qedit_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('qedit_nonce')
    ]);
}

add_action('wp_ajax_qedit_save_edits', 'qeditpro_save_edits');
function qeditpro_save_edits() {
    check_ajax_referer('qedit_nonce', 'nonce');

    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized');
    }

    $products = $_POST['products'] ?? [];

    foreach ($products as $id => $data) {
        $product = wc_get_product((int) $id);
        if (!$product) continue;

        $product->set_name(sanitize_text_field($data['title']));
        $product->set_sku(sanitize_text_field($data['sku']));
        $product->set_regular_price(wc_format_decimal($data['price']));
        $product->set_sale_price(wc_format_decimal($data['sale_price']));
        $product->set_stock_quantity(intval($data['stock']));
        $product->set_status(sanitize_text_field($data['status']));
        $product->set_weight(sanitize_text_field($data['weight']));
        $product->set_length(sanitize_text_field($data['length']));
        $product->set_width(sanitize_text_field($data['width']));
        $product->set_height(sanitize_text_field($data['height']));
        $product->set_catalog_visibility(sanitize_text_field($data['visibility']));
        $product->set_tax_class(sanitize_text_field($data['tax_class']));

        wp_set_object_terms($product->get_id(), array_map('sanitize_text_field', explode(',', $data['categories'])), 'product_cat');
        wp_set_object_terms($product->get_id(), array_map('sanitize_text_field', explode(',', $data['tags'])), 'product_tag');

        $product->save();
    }

    wp_send_json_success('Products updated successfully.');
}

function qeditpro_render_page() {
    if (!qeditpro_license_is_valid()) {
        echo '<div class="wrap"><h1>Quick Edit Pro</h1><p>This feature is locked. Please activate your license.</p></div>';
        return;
    }

    include plugin_dir_path(__FILE__) . 'qedit-template.php';
}
