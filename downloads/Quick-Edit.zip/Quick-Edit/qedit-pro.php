<?php
/**
 * Plugin Name: Quick Edit
 * Plugin URI: https://quickwoo.pro/quick-edit
 * Description: Bulk edit WooCommerce products from one screen. Unlocks all fields. Requires valid license.
 * Version: 1.0
 * Author: Robert Calvin
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: quick-edit
 */

defined('ABSPATH') || exit;

require_once plugin_dir_path(__FILE__) . 'license-check.php';

add_action('admin_menu', function () {
    add_menu_page(
        'Quick Edit',
        'Quick Edit',
        'manage_woocommerce',
        'quick-edit',
        'qedit_render_page',
        'dashicons-edit',
        58
    );
});

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook === 'toplevel_page_quick-edit') {
        wp_enqueue_style('qedit-style', plugin_dir_url(__FILE__) . 'qedit-style.css', [], null);
        wp_enqueue_script('qedit-script', plugin_dir_url(__FILE__) . 'qedit-script.js', ['jquery'], null, true);
        wp_localize_script('qedit-script', 'qedit_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('qedit_nonce')
        ]);
    }
});

add_action('wp_ajax_qedit_save_edits', function () {
    check_ajax_referer('qedit_nonce', 'nonce');

    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized');
    }

    $products = $_POST['products'] ?? [];

    foreach ($products as $id => $data) {
        $product = wc_get_product((int) $id);
        if (!$product) continue;

        $product->set_name(sanitize_text_field($data['title']));
        $product->set_sku(sanitize_text_field($data['sku']));
        $product->set_regular_price(wc_format_decimal($data['price']));
        $product->set_sale_price(wc_format_decimal($data['sale_price']));
        $product->set_stock_quantity(intval($data['stock']));
        $product->set_status(sanitize_text_field($data['status']));
        $product->set_weight(sanitize_text_field($data['weight']));
        $product->set_length(sanitize_text_field($data['length']));
        $product->set_width(sanitize_text_field($data['width']));
        $product->set_height(sanitize_text_field($data['height']));
        $product->set_catalog_visibility(sanitize_text_field($data['visibility']));
        $product->set_tax_class(sanitize_text_field($data['tax_class']));

        wp_set_object_terms($product->get_id(), array_map('sanitize_text_field', explode(',', $data['categories'])), 'product_cat');
        wp_set_object_terms($product->get_id(), array_map('sanitize_text_field', explode(',', $data['tags'])), 'product_tag');

        $product->save();
    }

    wp_send_json_success('Products updated successfully.');
});

function qedit_render_page() {
    $license = get_option('quickwoo_license_key');
    $email = get_option('quickwoo_license_email');

    $response = wp_remote_post('https://api.quickwoo.pro/verify-license', [
        'timeout' => 10,
        'body' => [
            'license_key' => $license,
            'email'       => $email,
            'plugin'      => 'quick-edit'
        ]
    ]);

    $is_valid = false;

    if (!is_wp_error($response)) {
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $is_valid = isset($body['valid']) && $body['valid'] === true;
    }

    if (!$is_valid) {
        echo '<div class="wrap"><h1>Quick Edit</h1><p>This feature is locked. Please activate your license in Settings > QuickWoo License.</p></div>';
        return;
    }

    include plugin_dir_path(__FILE__) . 'qedit-template.php';
}
