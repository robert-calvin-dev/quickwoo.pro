jQuery(document).ready(function ($) {
 $('#qedit-form').on('submit', function (e) {
   e.preventDefault();

   const products = {};

   $('tr[data-product-id]').each(function () {
     const row = $(this);
     const id = row.data('product-id');

     products[id] = {
       title: row.find('input[name="title"]').val().trim(),
       sku: row.find('input[name="sku"]').val().trim(),
       price: row.find('input[name="price"]').val().trim(),
       sale_price: row.find('input[name="sale_price"]').val().trim(),
       stock: row.find('input[name="stock"]').val().trim(),
       status: row.find('select[name="status"]').val().trim(),
       visibility: row.find('select[name="visibility"]').val().trim(),
       weight: row.find('input[name="weight"]').val().trim(),
       length: row.find('input[name="length"]').val().trim(),
       width: row.find('input[name="width"]').val().trim(),
       height: row.find('input[name="height"]').val().trim(),
       tax_class: row.find('select[name="tax_class"]').val().trim(),
       categories: row.find('input[name="categories"]').val().trim(),
       tags: row.find('input[name="tags"]').val().trim()
     };
   });

   $.ajax({
     url: qedit_ajax.ajax_url,
     method: 'POST',
     data: {
       action: 'qedit_save_edits',
       nonce: qedit_ajax.nonce,
       products: products
     },
     success: function (res) {
       if (res.success) {
         alert('✔ ' + res.data);
       } else {
         alert('✖ ' + res.data);
       }
     },
     error: function () {
       alert('Server error occurred while saving products.');
     }
   });
 });
});
