<?php
if (!defined('ABSPATH')) exit;

$products = wc_get_products(['limit' => -1]);
?>

<div class="wrap">
  <h1><?php esc_html_e('Quick Edit Pro – Product Editor', 'quick-edit-pro'); ?></h1>
  <form id="qedit-form">
    <table class="wp-list-table widefat fixed striped">
      <thead>
        <tr>
          <th><?php esc_html_e('Title', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('SKU', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Price', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Sale Price', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Stock', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Status', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Visibility', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Weight', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Length', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Width', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Height', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Tax Class', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Categories', 'quick-edit-pro'); ?></th>
          <th><?php esc_html_e('Tags', 'quick-edit-pro'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($products as $product): ?>
          <tr data-product-id="<?php echo esc_attr($product->get_id()); ?>">
            <td><input type="text" name="title" value="<?php echo esc_attr($product->get_name()); ?>" /></td>
            <td><input type="text" name="sku" value="<?php echo esc_attr($product->get_sku()); ?>" /></td>
            <td><input type="number" name="price" step="0.01" value="<?php echo esc_attr($product->get_regular_price()); ?>" /></td>
            <td><input type="number" name="sale_price" step="0.01" value="<?php echo esc_attr($product->get_sale_price()); ?>" /></td>
            <td><input type="number" name="stock" value="<?php echo esc_attr($product->get_stock_quantity()); ?>" /></td>
            <td>
              <select name="status">
                <option value="publish" <?php selected($product->get_status(), 'publish'); ?>><?php esc_html_e('Published', 'quick-edit-pro'); ?></option>
                <option value="draft" <?php selected($product->get_status(), 'draft'); ?>><?php esc_html_e('Draft', 'quick-edit-pro'); ?></option>
              </select>
            </td>
            <td>
              <select name="visibility">
                <?php foreach (wc_get_product_visibility_options() as $key => $label): ?>
                  <option value="<?php echo esc_attr($key); ?>" <?php selected($product->get_catalog_visibility(), $key); ?>>
                    <?php echo esc_html($label); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </td>
            <td><input type="text" name="weight" value="<?php echo esc_attr($product->get_weight()); ?>" /></td>
            <td><input type="text" name="length" value="<?php echo esc_attr($product->get_length()); ?>" /></td>
            <td><input type="text" name="width" value="<?php echo esc_attr($product->get_width()); ?>" /></td>
            <td><input type="text" name="height" value="<?php echo esc_attr($product->get_height()); ?>" /></td>
            <td>
              <select name="tax_class">
                <option value="" <?php selected($product->get_tax_class(), ''); ?>><?php esc_html_e('Standard', 'quick-edit-pro'); ?></option>
                <?php foreach (WC_Tax::get_tax_classes() as $class): ?>
                  <option value="<?php echo esc_attr($class); ?>" <?php selected($product->get_tax_class(), $class); ?>>
                    <?php echo esc_html($class); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </td>
            <td><input type="text" name="categories" value="<?php echo esc_attr(join(', ', wp_get_post_terms($product->get_id(), 'product_cat', ['fields' => 'names']))); ?>" /></td>
            <td><input type="text" name="tags" value="<?php echo esc_attr(join(', ', wp_get_post_terms($product->get_id(), 'product_tag', ['fields' => 'names']))); ?>" /></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <p>
      <button type="submit" class="button button-primary">
        <?php esc_html_e('Save Changes', 'quick-edit-pro'); ?>
      </button>
    </p>
  </form>
</div>
