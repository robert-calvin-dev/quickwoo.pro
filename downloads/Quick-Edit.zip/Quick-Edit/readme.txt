=== Quick Edit Pro ===
Contributors: robertcalvin
Tags: woocommerce, bulk edit, product editor, quick edit, inventory, spreadsheet, pro
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Edit unlimited WooCommerce products in a spreadsheet-style interface. Update price, stock, dimensions, tax class, and more — all from one screen.

== Description ==

**Quick Edit Pro** gives WooCommerce store owners a lightning-fast admin screen to update key product fields without CSVs or exports. It expands on the Lite version with full field coverage and no limits.

**Features:**
* Unlimited product editing
* Spreadsheet-style inline editing
* Edit title, SKU, price, sale price, stock, weight, dimensions
* Edit tax class, visibility, product status, categories, and tags
* AJAX-powered save system (no page reloads)
* License key activation for full access

== Installation ==

1. Upload to `/wp-content/plugins/`
2. Activate via WordPress Plugins menu
3. Activate license under **Products > Activate License**
4. Use **Products > Quick Edit Pro** to begin editing

== Screenshots ==

1. Bulk edit interface
2. Edit dozens of products in one go
3. Save instantly via AJAX

== Changelog ==

= 1.0 =
* Initial release of Pro version

== Upgrade Notice ==
Pro version unlocks full WooCommerce field editing and removes row limits.
