<?php
function qseo_license_page() {
  if ($_POST['qseo_license']) {
    update_option('qseo_pro_license_key', sanitize_text_field($_POST['qseo_license']));
    echo '<div class="updated"><p>License updated successfully!</p></div>';
  }
  $license = get_option('qseo_pro_license_key', '');
  ?>
  <div class="wrap">
    <h2>Activate Quick SEO Pro License</h2>
    <form method="post">
      <input type="text" name="qseo_license" value="<?php echo esc_attr($license); ?>" class="regular-text">
      <button type="submit" class="button button-primary">Activate</button>
    </form>
  </div>
<?php } ?>
