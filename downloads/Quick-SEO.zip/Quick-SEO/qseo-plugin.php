<?php
/**
 * Plugin Name: Quick SEO
 * Description: Full-featured spreadsheet-style SEO editor for WooCommerce products with unlimited editing, schema, and OG image support. Requires valid license.
 * Version: 2.0
 * Author: Robert Calvin
 * Text Domain: quick-seo
 */

defined('ABSPATH') || exit;

require_once plugin_dir_path(__FILE__) . 'license-check.php';

add_action('admin_menu', function () {
  add_menu_page('Quick SEO', 'Quick SEO', 'manage_options', 'quick-seo', 'qseo_render_page', 'dashicons-chart-line', 58);
});

add_action('admin_enqueue_scripts', function ($hook) {
  if ($hook === 'toplevel_page_quick-seo') {
    wp_enqueue_script('qseo-js', plugin_dir_url(__FILE__) . 'qseo-script.js', ['jquery'], '2.0', true);
    wp_localize_script('qseo-js', 'qseo_ajax', [
      'ajax_url' => admin_url('admin-ajax.php'),
      'nonce' => wp_create_nonce('qseo_nonce')
    ]);
    wp_enqueue_style('qseo-css', plugin_dir_url(__FILE__) . 'qseo-style.css');
  }
});

function qseo_render_page() {
  $license = get_option('quickwoo_license_key');
  $email = get_option('quickwoo_license_email');

  $response = wp_remote_post('https://api.quickwoo.pro/verify-license', [
    'timeout' => 10,
    'body' => [
      'license_key' => $license,
      'email'       => $email,
      'plugin'      => 'quick-seo'
    ]
  ]);

  $is_valid = false;

  if (!is_wp_error($response)) {
    $body = json_decode(wp_remote_retrieve_body($response), true);
    $is_valid = isset($body['valid']) && $body['valid'] === true;
  }

  if (!$is_valid) {
    echo '<div class="wrap"><h1>Quick SEO</h1><p>This feature is locked. Please activate your license in Settings > QuickWoo License.</p></div>';
    return;
  }

  include 'qseo-template.php';
}

// AJAX Handler: Save SEO Data
add_action('wp_ajax_qseo_pro_save', 'qseo_pro_save');
function qseo_pro_save() {
  check_ajax_referer('qseo_nonce', 'security');
  parse_str(wp_unslash($_POST['data']), $form_data);

  foreach ($form_data['products'] as $product_id => $fields) {
    update_post_meta($product_id, '_qseo_focus_keyword', sanitize_text_field($fields['focus_keyword']));
    update_post_meta($product_id, '_qseo_seo_title', sanitize_text_field($fields['seo_title']));
    update_post_meta($product_id, '_qseo_meta_description', sanitize_textarea_field($fields['meta_description']));
    update_post_meta($product_id, '_qseo_og_title', sanitize_text_field($fields['og_title']));
    update_post_meta($product_id, '_qseo_og_description', sanitize_textarea_field($fields['og_description']));
    update_post_meta($product_id, '_qseo_og_image', esc_url_raw($fields['og_image']));
    update_post_meta($product_id, '_qseo_schema_type', sanitize_text_field($fields['schema_type']));
    update_post_meta($product_id, '_qseo_schema_brand', sanitize_text_field($fields['schema_brand']));
    update_post_meta($product_id, '_qseo_schema_availability', sanitize_text_field($fields['schema_availability']));
  }

  wp_send_json_success('SEO data saved successfully.');
}

// Output SEO & Schema Data to Product Page <head>
add_action('wp_head', 'qseo_pro_output_meta');
function qseo_pro_output_meta() {
  if (is_product()) {
    global $post;
    $meta_fields = [
      '_qseo_seo_title' => 'title',
      '_qseo_meta_description' => 'description',
      '_qseo_og_title' => 'og:title',
      '_qseo_og_description' => 'og:description',
      '_qseo_og_image' => 'og:image'
    ];

    foreach ($meta_fields as $meta_key => $tag) {
      $value = get_post_meta($post->ID, $meta_key, true);
      if ($value) {
        if ($tag === 'title') {
          echo '<title>' . esc_html($value) . '</title>';
        } else if ($tag === 'description') {
          echo '<meta name="description" content="' . esc_attr($value) . '">';
        } else {
          echo '<meta property="' . esc_attr($tag) . '" content="' . esc_attr($value) . '">';
        }
      }
    }

    // JSON-LD Schema output
    $schema_type = get_post_meta($post->ID, '_qseo_schema_type', true);
    $schema_brand = get_post_meta($post->ID, '_qseo_schema_brand', true);
    $schema_availability = get_post_meta($post->ID, '_qseo_schema_availability', true);
    $price = get_post_meta($post->ID, '_price', true);

    if ($schema_type && $schema_brand && $schema_availability && $price) {
      $schema = [
        "@context" => "https://schema.org/",
        "@type" => esc_html($schema_type),
        "name" => esc_html(get_the_title($post->ID)),
        "brand" => esc_html($schema_brand),
        "offers" => [
          "@type" => "Offer",
          "availability" => esc_html($schema_availability),
          "price" => esc_html($price),
          "priceCurrency" => esc_html(get_woocommerce_currency()),
          "url" => esc_url(get_permalink($post->ID))
        ]
      ];

      echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_PRETTY_PRINT) . '</script>';
    }
  }
}

// Add SEO fields Metabox to WooCommerce Product Edit Screen
add_action('add_meta_boxes', function () {
  add_meta_box(
    'qseo_product_seo_pro',
    __('Quick SEO Pro', 'quick-seo-pro'),
    'qseo_pro_render_metabox',
    'product',
    'normal',
    'default'
  );
});

// Render Metabox Fields
function qseo_pro_render_metabox($post) {
  $fields = [
    'focus_keyword' => 'Focus Keyword',
    'seo_title' => 'SEO Title',
    'meta_description' => 'Meta Description',
    'og_title' => 'OG Title',
    'og_description' => 'OG Description',
    'og_image' => 'OG Image URL',
    'schema_type' => 'Schema Type',
    'schema_brand' => 'Schema Brand',
    'schema_availability' => 'Schema Availability'
  ];

  foreach ($fields as $key => $label) {
    $value = get_post_meta($post->ID, '_qseo_' . $key, true);
    echo '<p><label><strong>' . esc_html($label) . ':</strong><br />';
    if (in_array($key, ['meta_description', 'og_description'])) {
      echo '<textarea name="qseo_' . esc_attr($key) . '" rows="3" style="width:100%;">' . esc_textarea($value) . '</textarea>';
    } else {
      echo '<input type="text" name="qseo_' . esc_attr($key) . '" value="' . esc_attr($value) . '" style="width:100%;" />';
    }
    echo '</label></p>';
  }
}

// Save Metabox Data
add_action('save_post_product', function ($post_id) {
  if (!current_user_can('edit_product', $post_id)) return;
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

  foreach (['focus_keyword', 'seo_title', 'meta_description', 'og_title', 'og_description', 'og_image', 'schema_type', 'schema_brand', 'schema_availability'] as $key) {
    if (isset($_POST['qseo_' . $key])) {
      update_post_meta($post_id, '_qseo_' . $key, sanitize_text_field($_POST['qseo_' . $key]));
    }
  }
});
