<?php
/**
 * Plugin Name: Quick SEO Pro
 * Description: Full-featured spreadsheet-style SEO editor for WooCommerce products with unlimited editing, schema, and OG image support.
 * Version: 2.0
 * Author: Robert Calvin
 * Text Domain: quick-seo-pro
 */

defined('ABSPATH') || exit;

// Register Admin Menu and License Page
add_action('admin_menu', 'qseo_pro_register_menu');
function qseo_pro_register_menu() {
  add_menu_page('Quick SEO Pro', 'Quick SEO Pro', 'manage_options', 'quick-seo-pro', 'qseo_pro_render_page', 'dashicons-chart-line', 58);
  add_submenu_page('quick-seo-pro', 'Activate License', 'Activate License', 'manage_options', 'quick-seo-pro-license', 'qseo_license_page');
}

// Enqueue Admin Scripts and Styles
add_action('admin_enqueue_scripts', 'qseo_pro_enqueue_assets');
function qseo_pro_enqueue_assets($hook) {
  if ($hook === 'toplevel_page_quick-seo-pro') {
    wp_enqueue_script('qseo-pro-js', plugin_dir_url(__FILE__) . 'qseo-script.js', ['jquery'], '2.0', true);
    wp_localize_script('qseo-pro-js', 'qseo_ajax', [
      'ajax_url' => admin_url('admin-ajax.php'),
      'nonce' => wp_create_nonce('qseo_nonce')
    ]);
    wp_enqueue_style('qseo-pro-css', plugin_dir_url(__FILE__) . 'qseo-style.css');
  }
}

// Render Main Admin Page
function qseo_pro_render_page() {
  include 'qseo-template.php';
}

// AJAX Handler: Save SEO Data
add_action('wp_ajax_qseo_pro_save', 'qseo_pro_save');
function qseo_pro_save() {
  check_ajax_referer('qseo_nonce', 'security');
  parse_str(wp_unslash($_POST['data']), $form_data);

  foreach ($form_data['products'] as $product_id => $fields) {
    update_post_meta($product_id, '_qseo_focus_keyword', sanitize_text_field($fields['focus_keyword']));
    update_post_meta($product_id, '_qseo_seo_title', sanitize_text_field($fields['seo_title']));
    update_post_meta($product_id, '_qseo_meta_description', sanitize_textarea_field($fields['meta_description']));
    update_post_meta($product_id, '_qseo_og_title', sanitize_text_field($fields['og_title']));
    update_post_meta($product_id, '_qseo_og_description', sanitize_textarea_field($fields['og_description']));
    update_post_meta($product_id, '_qseo_og_image', esc_url_raw($fields['og_image']));
    update_post_meta($product_id, '_qseo_schema_type', sanitize_text_field($fields['schema_type']));
    update_post_meta($product_id, '_qseo_schema_brand', sanitize_text_field($fields['schema_brand']));
    update_post_meta($product_id, '_qseo_schema_availability', sanitize_text_field($fields['schema_availability']));
  }

  wp_send_json_success('SEO data saved successfully.');
}

// Output SEO & Schema Data to Product Page <head>
add_action('wp_head', 'qseo_pro_output_meta');
function qseo_pro_output_meta() {
  if (is_product()) {
    global $post;
    $meta_fields = [
      '_qseo_seo_title' => 'title',
      '_qseo_meta_description' => 'description',
      '_qseo_og_title' => 'og:title',
      '_qseo_og_description' => 'og:description',
      '_qseo_og_image' => 'og:image'
    ];

    foreach ($meta_fields as $meta_key => $tag) {
      $value = get_post_meta($post->ID, $meta_key, true);
      if ($value) {
        if ($tag === 'title') {
          echo '<title>' . esc_html($value) . '</title>';
        } else if ($tag === 'description') {
          echo '<meta name="description" content="' . esc_attr($value) . '">';
        } else {
          echo '<meta property="' . esc_attr($tag) . '" content="' . esc_attr($value) . '">';
        }
      }
    }

    // JSON-LD Schema output
    $schema_type = get_post_meta($post->ID, '_qseo_schema_type', true);
    $schema_brand = get_post_meta($post->ID, '_qseo_schema_brand', true);
    $schema_availability = get_post_meta($post->ID, '_qseo_schema_availability', true);
    $price = get_post_meta($post->ID, '_price', true);

    if ($schema_type && $schema_brand && $schema_availability && $price) {
      $schema = [
        "@context" => "https://schema.org/",
        "@type" => esc_html($schema_type),
        "name" => esc_html(get_the_title($post->ID)),
        "brand" => esc_html($schema_brand),
        "offers" => [
          "@type" => "Offer",
          "availability" => esc_html($schema_availability),
          "price" => esc_html($price),
          "priceCurrency" => esc_html(get_woocommerce_currency()),
          "url" => esc_url(get_permalink($post->ID))
        ]
      ];

      echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_PRETTY_PRINT) . '</script>';
    }
  }
}

// Add SEO fields Metabox to WooCommerce Product Edit Screen
add_action('add_meta_boxes', function () {
  add_meta_box(
    'qseo_product_seo_pro',
    __('Quick SEO Pro', 'quick-seo-pro'),
    'qseo_pro_render_metabox',
    'product',
    'normal',
    'default'
  );
});

// Render Metabox Fields
function qseo_pro_render_metabox($post) {
  $fields = [
    'focus_keyword' => 'Focus Keyword',
    'seo_title' => 'SEO Title',
    'meta_description' => 'Meta Description',
    'og_title' => 'OG Title',
    'og_description' => 'OG Description',
    'og_image' => 'OG Image URL',
    'schema_type' => 'Schema Type',
    'schema_brand' => 'Schema Brand',
    'schema_availability' => 'Schema Availability'
  ];

  foreach ($fields as $key => $label) {
    $value = get_post_meta($post->ID, '_qseo_' . $key, true);
    echo '<p><label><strong>' . esc_html($label) . ':</strong><br />';
    if (in_array($key, ['meta_description', 'og_description'])) {
      echo '<textarea name="qseo_' . esc_attr($key) . '" rows="3" style="width:100%;">' . esc_textarea($value) . '</textarea>';
    } else {
      echo '<input type="text" name="qseo_' . esc_attr($key) . '" value="' . esc_attr($value) . '" style="width:100%;" />';
    }
    echo '</label></p>';
  }
}

// Save Metabox Data
add_action('save_post_product', function ($post_id) {
  if (!current_user_can('edit_product', $post_id)) return;
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

  foreach (['focus_keyword', 'seo_title', 'meta_description', 'og_title', 'og_description', 'og_image', 'schema_type', 'schema_brand', 'schema_availability'] as $key) {
    if (isset($_POST['qseo_' . $key])) {
      update_post_meta($post_id, '_qseo_' . $key, sanitize_text_field($_POST['qseo_' . $key]));
    }
  }
});
