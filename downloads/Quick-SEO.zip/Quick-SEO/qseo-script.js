jQuery(document).ready(function ($) {
 $('#qseo-form').on('submit', function (e) {
   e.preventDefault();

   const formData = $(this).serialize();

   $.ajax({
     url: qseo_ajax.ajax_url,
     type: 'POST',
     data: {
       action: 'qseo_pro_save',
       security: qseo_ajax.nonce,
       data: formData
     },
     success: function (response) {
       if (response.success) {
         alert(response.data);
       } else {
         alert('Error: ' + response.data);
       }
     },
     error: function () {
       alert('Server error occurred.');
     }
   });
 });
});
