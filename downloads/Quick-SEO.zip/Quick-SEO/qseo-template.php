<?php
function qseo_render_template() {
  $products = wc_get_products(['limit' => -1]); // unlimited products
?>
<div class="wrap">
  <h1>Quick SEO Pro – Product SEO Editor</h1>
  <form id="qseo-form">
    <table class="wp-list-table widefat fixed striped">
      <thead>
        <tr>
          <th>Name</th>
          <th>Focus Keyword</th>
          <th>SEO Title</th>
          <th>Meta Description</th>
          <th>OG Title</th>
          <th>OG Description</th>
          <th>OG Image URL</th>
          <th>Schema Type</th>
          <th>Schema Brand</th>
          <th>Schema Availability</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($products as $product): ?>
        <tr>
          <td><?php echo esc_html($product->get_name()); ?></td>
          <?php foreach (['focus_keyword', 'seo_title', 'meta_description', 'og_title', 'og_description', 'og_image', 'schema_type', 'schema_brand', 'schema_availability'] as $meta_key): ?>
            <td><input type="text" name="products[<?php echo esc_attr($product->get_id()); ?>][<?php echo esc_attr($meta_key); ?>]" value="<?php echo esc_attr(get_post_meta($product->get_id(), $meta_key, true)); ?>"></td>
          <?php endforeach; ?>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <button type="submit" class="button button-primary">Save All</button>
  </form>
</div>
<?php } ?>
