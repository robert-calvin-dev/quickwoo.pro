=== Quick SEO Pro ===
Contributors: robertcalvin
Tags: woocommerce, seo, spreadsheet, schema, open graph, meta description
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Advanced spreadsheet-style SEO editor with unlimited WooCommerce product editing, schema injection, and Open Graph image support.

== Description ==
Quick SEO Pro lets WooCommerce store owners manage essential SEO fields quickly with a powerful, spreadsheet-style interface.

**Pro Features Include:**
- Unlimited product editing
- Schema type, brand, and availability customization
- Open Graph image support
- AJAX-powered saving
- SEO tags output automatically to product pages' `<head>`

== Installation ==
1. Upload the plugin to `/wp-content/plugins/`
2. Activate via the "Plugins" menu in WordPress
3. Go to WooCommerce > Quick SEO Pro to manage your SEO data

== Changelog ==
= 2.0 =
* Full Pro release: unlimited editing, schema, OG images
